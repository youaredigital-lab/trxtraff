"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

export function Nav({ items }: { items: { href: string; label: string; count?: number; hot?: boolean }[] }) {
  const path = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto md:flex-col md:gap-0.5">
      {items.map((i) => {
        const active = i.href === "/" ? path === "/" : path.startsWith(i.href);
        return (
          <Link
            key={i.href}
            href={i.href}
            aria-current={active ? "page" : undefined}
            className={`flex items-center justify-between gap-2 whitespace-nowrap rounded-lg px-2.5 py-2 font-medium ${
              active ? "bg-accent-soft text-ink" : "text-muted hover:bg-sunk hover:text-ink"
            }`}
          >
            <span>{i.label}</span>
            {!!i.count && (
              <span className={`rounded-full px-2 font-mono text-[11.5px] ${i.hot ? "bg-neg-soft text-neg" : "bg-sunk text-muted"}`}>{i.count}</span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}
