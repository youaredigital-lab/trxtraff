"use client";
import { useRef, useState } from "react";

type Ticket = { path: string; signedUrl: string } | { error: string };

/**
 * Загрузка видео напрямую в Supabase Storage по подписанной ссылке (файл не проходит через сервер Next.js).
 * Путь загруженного файла кладётся в скрытое поле `name`.
 */
export function VideoUpload({ name, folder, current, getTicket }: { name: string; folder: "lessons" | "meetings"; current?: string | null; getTicket: (folder: string, filename: string) => Promise<Ticket> }) {
  const [path, setPath] = useState(current ?? "");
  const [progress, setProgress] = useState<number | null>(null);
  const [err, setErr] = useState("");
  const input = useRef<HTMLInputElement>(null);

  async function onFile(file: File) {
    setErr("");
    const t = await getTicket(folder, file.name);
    if ("error" in t) { setErr(t.error); return; }
    setProgress(0);
    await new Promise<void>((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open("PUT", t.signedUrl);
      xhr.setRequestHeader("x-upsert", "false");
      xhr.setRequestHeader("content-type", file.type || "video/mp4");
      xhr.setRequestHeader("cache-control", "max-age=3600");
      xhr.upload.onprogress = (e) => e.lengthComputable && setProgress(Math.round((e.loaded / e.total) * 100));
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) setPath(t.path);
        else setErr(xhr.status === 413 ? "Файл больше лимита хранилища. Увеличьте лимит в Supabase или используйте ссылку." : `Загрузка не удалась (${xhr.status})`);
        setProgress(null);
        resolve();
      };
      xhr.onerror = () => { setErr("Сеть оборвалась — попробуйте ещё раз"); setProgress(null); resolve(); };
      xhr.send(file);
    });
  }

  return (
    <div className="flex flex-col gap-2">
      <input type="hidden" name={name} value={path} />
      <input ref={input} type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
      <div className="flex flex-wrap items-center gap-2">
        <button type="button" className="btn" disabled={progress !== null} onClick={() => input.current?.click()}>
          {progress !== null ? `Загружаем… ${progress}%` : path ? "Заменить файл" : "Загрузить видео"}
        </button>
        {path && progress === null && (
          <>
            <span className="pill-ok max-w-[260px] truncate">{path.split("/").pop()}</span>
            <button type="button" className="btn-ghost btn-sm" onClick={() => setPath("")}>Убрать</button>
          </>
        )}
      </div>
      {progress !== null && <div className="h-2 overflow-hidden rounded-full bg-sunk"><span className="block h-full bg-accent transition-all" style={{ width: `${progress}%` }} /></div>}
      {err && <span className="text-[13px] text-neg">{err}</span>}
    </div>
  );
}
