import { embedUrl } from "@/lib/media";

export function VideoPlayer({ src, url, title }: { src?: string | null; url?: string | null; title: string }) {
  if (src) {
    return (
      <div className="overflow-hidden rounded-card border border-line bg-black">
        <video src={src} controls preload="metadata" className="aspect-video w-full" controlsList="nodownload" />
      </div>
    );
  }
  if (url) {
    const embed = embedUrl(url);
    if (embed) {
      return (
        <div className="overflow-hidden rounded-card border border-line bg-black">
          <iframe src={embed} title={title} className="aspect-video w-full" allow="autoplay; fullscreen; picture-in-picture" allowFullScreen />
        </div>
      );
    }
    return <a className="btn" href={url} target="_blank" rel="noopener noreferrer">Открыть видео</a>;
  }
  return null;
}
