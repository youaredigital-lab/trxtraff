"use client";
import { useState, useTransition } from "react";

/** Кнопка, вызывающая серверное действие ИИ и показывающая ответ. */
export function AiButton({ action, label, formId, saveAs }: { action: (fd: FormData) => Promise<{ text?: string; error?: string }>; label: string; formId?: string; saveAs?: string }) {
  const [out, setOut] = useState<{ text?: string; error?: string } | null>(null);
  const [pending, start] = useTransition();
  return (
    <div className="flex flex-col gap-2">
      <div>
        <button
          type="button"
          className="btn"
          disabled={pending}
          onClick={() =>
            start(async () => {
              const form = formId ? (document.getElementById(formId) as HTMLFormElement) : null;
              const fd = form ? new FormData(form) : new FormData();
              setOut(await action(fd));
            })
          }
        >
          {pending ? "Думаю…" : label}
        </button>
      </div>
      {saveAs && <input type="hidden" name={saveAs} value={out?.text ?? ""} />}
      {out?.text && <div className="whitespace-pre-wrap rounded-card bg-accent-soft p-4 text-[14px]">{out.text}</div>}
      {out?.error && <div className="rounded-card bg-neg-soft px-4 py-3 text-neg">{out.error}</div>}
    </div>
  );
}
