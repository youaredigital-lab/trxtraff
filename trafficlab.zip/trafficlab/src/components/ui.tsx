import Link from "next/link";
import type { ReactNode } from "react";

export function PageHead({ title, sub, children }: { title: ReactNode; sub?: ReactNode; children?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-semibold tracking-tight">{title}</h1>
        {sub && <p className="mt-1 text-muted">{sub}</p>}
      </div>
      {children && <div className="flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

export function Kpi({ label, value, tone = "", note }: { label: string; value: ReactNode; tone?: string; note?: ReactNode }) {
  return (
    <div className="card">
      <div className="kpi-l">{label}</div>
      <div className={`kpi-v ${tone}`}>{value}</div>
      {note && <div className="text-[12.5px] text-muted">{note}</div>}
    </div>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="rounded-card border border-dashed border-line bg-panel p-7 text-center text-muted">
      <b className="mb-1 block text-ink">{title}</b>
      {children}
    </div>
  );
}

export function Table({ children }: { children: ReactNode }) {
  return <div className="overflow-x-auto rounded-card border border-line bg-panel"><table className="tbl">{children}</table></div>;
}

export function Chips({ items, current, hrefFor }: { items: [string, string][]; current: string; hrefFor: (k: string) => string }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map(([k, l]) => (
        <Link key={k} href={hrefFor(k)} className={k === current ? "chip-on" : "chip"}>{l}</Link>
      ))}
    </div>
  );
}

export function Lock({ level, need, children }: { level: number; need: string; children?: ReactNode }) {
  return (
    <div className="rounded-card bg-warn-soft px-4 py-3">
      <b className="text-warn">Откроется на Trust Level {level}.</b> Нужно: {need}. {children}
    </div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: ReactNode; children: ReactNode }) {
  return (
    <label className="label">
      <span>{label}</span>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </label>
  );
}

/** Абзацы урока с поддержкой **жирного**. */
export function Prose({ text }: { text: string }) {
  return (
    <div className="max-w-[68ch] space-y-3">
      {text.split(/\n\s*\n/).filter(Boolean).map((p, i) => (
        <p key={i}>
          {p.split(/(\*\*[^*]+\*\*)/g).map((s, j) => (s.startsWith("**") ? <b key={j}>{s.slice(2, -2)}</b> : s))}
        </p>
      ))}
    </div>
  );
}

export function ErrorNote({ error }: { error?: string }) {
  if (!error) return null;
  return <div className="rounded-card bg-neg-soft px-4 py-3 text-neg">{error}</div>;
}
