import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendTelegram } from "@/lib/telegram";

/** Ежедневно в 21:00 по Киеву (18:00 UTC, см. vercel.json): напомнить байерам TL2+ заполнить дневник. */
export async function GET(req: Request) {
  if (req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ ok: false, error: "no service key" }, { status: 500 });
  const today = new Date().toISOString().slice(0, 10);
  const { data: people } = await admin.from("profiles").select("id, full_name, telegram_chat_id").in("role", ["student", "buyer"]).not("telegram_chat_id", "is", null);
  const { data: wrote } = await admin.from("diary_entries").select("user_id").eq("entry_date", today);
  const done = new Set((wrote ?? []).map((w) => w.user_id));
  let sent = 0;
  for (const p of people ?? []) {
    if (done.has(p.id)) continue;
    const { data: s } = await admin.rpc("user_stats", { p_uid: p.id }).single();
    if (((s as any)?.trust_level ?? 0) < 2) continue;
    await sendTelegram(p.telegram_chat_id, `${p.full_name}, запишите результаты дня в дневник — это минута и +10 XP.\n${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/diary/new`);
    sent++;
  }
  return NextResponse.json({ ok: true, sent });
}
