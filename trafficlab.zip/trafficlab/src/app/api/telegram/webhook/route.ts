import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendTelegram } from "@/lib/telegram";

/** Вебхук бота. Регистрация: https://api.telegram.org/bot<TOKEN>/setWebhook?url=<SITE>/api/telegram/webhook&secret_token=<CRON_SECRET> */
export async function POST(req: Request) {
  if (req.headers.get("x-telegram-bot-api-secret-token") !== process.env.CRON_SECRET) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  const update = await req.json();
  const msg = update.message;
  const text: string = msg?.text ?? "";
  const chatId = msg?.chat?.id;
  if (!chatId) return NextResponse.json({ ok: true });

  if (text.startsWith("/start")) {
    const code = text.split(" ")[1];
    const admin = createAdminClient();
    if (code && admin) {
      const { data } = await admin.from("profiles").update({ telegram_chat_id: chatId }).eq("telegram_link_code", code).select("full_name").maybeSingle();
      if (data) {
        await sendTelegram(chatId, `Готово, ${data.full_name}! Сюда будут приходить уведомления TrafficLab.`);
        return NextResponse.json({ ok: true });
      }
    }
    await sendTelegram(chatId, "Откройте TrafficLab → Профиль → «Привязать Telegram», чтобы получать уведомления.");
  }
  return NextResponse.json({ ok: true });
}
