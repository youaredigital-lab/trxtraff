"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { notifyStaff, notifyUser } from "@/lib/telegram";

export async function createTicket(fd: FormData) {
  const { supabase, profile } = await getMe();
  const title = String(fd.get("title") ?? "").trim();
  const { data, error } = await supabase.from("tickets").insert({
    type: "ticket", title, category: String(fd.get("category")), priority: String(fd.get("priority")),
  }).select("id").single();
  if (error) redirect(`/tickets/new?error=${encodeURIComponent(error.message)}`);
  const body = String(fd.get("body") ?? "").trim();
  if (body) await supabase.from("ticket_messages").insert({ ticket_id: data.id, body });
  await notifyStaff(`${fd.get("priority") === "critical" ? "🔴 КРИТИЧНЫЙ " : ""}Тикет от ${profile.full_name}: ${title}`, `/tickets/${data.id}`);
  redirect(`/tickets/${data.id}`);
}

export async function postMessage(fd: FormData) {
  const { supabase, isStaff, profile } = await getMe();
  const id = String(fd.get("ticket_id"));
  const body = String(fd.get("body") ?? "").trim();
  if (!body) redirect(`/tickets/${id}`);
  const internal = isStaff && fd.get("internal") === "on";
  await supabase.from("ticket_messages").insert({ ticket_id: id, body, is_internal: internal });
  const { data: t } = await supabase.from("tickets").select("user_id, title").eq("id", id).single();
  if (t && !internal) {
    if (isStaff) await notifyUser(t.user_id, `Ответ по «${t.title}»: ${body.slice(0, 200)}`, `/tickets/${id}`);
    else await notifyStaff(`${profile.full_name} ответил в «${t.title}»`, `/tickets/${id}`);
  }
  revalidatePath(`/tickets/${id}`);
  redirect(`/tickets/${id}`);
}

export async function updateTicket(fd: FormData) {
  const { supabase, isStaff } = await getMe();
  const id = String(fd.get("ticket_id"));
  if (!isStaff) redirect(`/tickets/${id}`);
  const status = String(fd.get("status"));
  const { data: t } = await supabase.from("tickets").update({ status, priority: String(fd.get("priority")) }).eq("id", id).select("user_id, title").single();
  if (t && ["done", "rejected", "waiting"].includes(status)) {
    const word = { done: "решён", rejected: "отклонён", waiting: "ждёт вашего ответа" }[status];
    await notifyUser(t.user_id, `«${t.title}» — ${word}`, `/tickets/${id}`);
  }
  revalidatePath(`/tickets/${id}`);
  redirect(`/tickets/${id}`);
}

export async function rateTicket(fd: FormData) {
  const { supabase } = await getMe();
  const id = String(fd.get("ticket_id"));
  await supabase.from("tickets").update({ csat: Number(fd.get("csat")) }).eq("id", id);
  revalidatePath(`/tickets/${id}`);
  redirect(`/tickets/${id}`);
}
