import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Chips, Empty, PageHead, Table } from "@/components/ui";
import { PRIORITY, TICKET_STATUS, TICKET_TYPES } from "@/lib/constants";
import { ago, dur } from "@/lib/format";
import { isClosed, slaLeft } from "@/lib/sla";

export default async function Tickets({ searchParams }: { searchParams: { type?: string; st?: string } }) {
  const { supabase, user, isStaff, isAdmin } = await getMe();
  const type = searchParams.type ?? (isStaff ? "all" : "ticket");
  const st = searchParams.st ?? "open";
  let q = supabase.from("tickets").select("*, profiles!tickets_user_id_fkey(full_name)").order("created_at", { ascending: false }).limit(300);
  if (!isStaff) q = q.eq("user_id", user.id);
  if (type !== "all") q = q.eq("type", type);
  if (st === "open") q = q.in("status", ["open", "progress", "waiting"]);
  if (st === "done") q = q.in("status", ["done", "rejected"]);
  const { data } = await q;
  const rows = (data ?? []).sort((a, b) => (isClosed(a) === isClosed(b) ? slaLeft(a) - slaLeft(b) : isClosed(a) ? 1 : -1));
  const rated = (data ?? []).filter((t) => t.csat);
  const qs = (o: Record<string, string>) => "/tickets?" + new URLSearchParams({ type, st, ...o }).toString();

  return (
    <>
      <PageHead title="Тикеты" sub={isStaff ? "Единая очередь: тикеты и все заявки, отсортированы по SLA первого ответа." : "Вопросы и проблемы. Ответим в пределах SLA выбранного приоритета."}>
        <Link className="btn-pri" href="/tickets/new">Новый тикет</Link>
      </PageHead>
      <div className="mb-3.5 flex flex-col gap-2">
        {isStaff && <Chips current={type} hrefFor={(k) => qs({ type: k })} items={[["all", "Все типы"], ...Object.entries(TICKET_TYPES)] as [string, string][]} />}
        <Chips current={st} hrefFor={(k) => qs({ st: k })} items={[["open", "Открытые"], ["done", "Закрытые"], ["all", "Все"]]} />
        {isStaff && rated.length > 0 && <p className="hint">Средняя оценка поддержки: <b className="font-mono">{(rated.reduce((a, t) => a + t.csat, 0) / rated.length).toFixed(1)}</b> из 5 по {rated.length} тикетам</p>}
      </div>
      {!rows.length ? <Empty title="Тикетов нет">{isStaff ? "В этой выборке пусто." : "Если что-то не работает — создайте тикет."}</Empty> : (
        <Table>
          <thead><tr>{isStaff && <><th>Тип</th><th>Автор</th></>}<th>Тема</th><th>Приоритет</th><th>Статус</th><th>SLA ответа</th><th>Обновлён</th></tr></thead>
          <tbody>
            {rows.map((t: any) => {
              const l = slaLeft(t);
              return (
                <tr key={t.id}>
                  {isStaff && <><td><span className="pill">{TICKET_TYPES[t.type]}</span></td><td>{t.anonymous && !isAdmin ? <span className="text-muted">анонимно</span> : t.profiles?.full_name}</td></>}
                  <td><Link className="text-accent" href={`/tickets/${t.id}`}>{t.title}</Link></td>
                  <td>{PRIORITY[t.priority]?.label}</td>
                  <td><span className="pill">{TICKET_STATUS[t.status]}</span></td>
                  <td>{isClosed(t) ? "—" : l === Infinity ? <span className="pill-ok">ответ дан</span> : l < 0 ? <span className="pill-bad">просрочено {dur(l)}</span> : <span className={l < 36e5 ? "pill-wait" : "pill"}>{dur(l)}</span>}</td>
                  <td>{ago(t.updated_at)}</td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      )}
    </>
  );
}
