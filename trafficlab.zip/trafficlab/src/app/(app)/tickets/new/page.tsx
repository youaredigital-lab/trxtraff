import Link from "next/link";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { PRIORITY } from "@/lib/constants";
import { createTicket } from "../actions";
import { TitleWithSimilar } from "./Similar";

export default function NewTicket({ searchParams }: { searchParams: { error?: string } }) {
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/tickets">← Тикеты</Link>
      <PageHead title="Новый тикет" sub="Пока вы пишете тему, система подскажет похожие решённые тикеты." />
      <form action={createTicket} className="card flex max-w-2xl flex-col gap-3.5">
        <ErrorNote error={searchParams.error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Категория">
            <select className="input" name="category">{["Технический сбой", "Оффер / партнёрка", "Доступы и инструменты", "Оплата и выплаты", "Обучение", "Другое"].map((c) => <option key={c}>{c}</option>)}</select>
          </Field>
          <Field label="Приоритет" hint="Критичный — только если прямо сейчас горят деньги.">
            <select className="input" name="priority" defaultValue="normal">
              {Object.entries(PRIORITY).map(([k, v]) => <option key={k} value={k}>{v.label} — ответ за {v.hours < 1 ? `${Math.round(v.hours * 60)} мин` : `${v.hours} ч`}</option>)}
            </select>
          </Field>
        </div>
        <TitleWithSimilar />
        <Field label="Подробности"><textarea className="input min-h-[120px]" name="body" placeholder="Что делали, что ожидали, что получили. Ссылки и скриншоты." /></Field>
        <div><Submit>Создать тикет</Submit></div>
      </form>
    </>
  );
}
