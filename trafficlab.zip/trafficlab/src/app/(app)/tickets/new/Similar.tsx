"use client";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

/** Поле темы с подсказкой похожих решённых тикетов. */
export function TitleWithSimilar() {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<{ title: string; answer: string | null }[]>([]);
  useEffect(() => {
    const word = q.split(/\s+/).filter((w) => w.length > 3).sort((a, b) => b.length - a.length)[0];
    if (!word) { setHits([]); return; }
    const t = setTimeout(async () => {
      const { data } = await createClient().rpc("similar_tickets", { p_query: word });
      setHits((data as any[]) ?? []);
    }, 350);
    return () => clearTimeout(t);
  }, [q]);
  return (
    <>
      <label className="label"><span>Тема</span><input className="input" name="title" required value={q} onChange={(e) => setQ(e.target.value)} placeholder="Не грузится лендинг оффера" /></label>
      {hits.length > 0 && (
        <div className="rounded-card bg-sunk p-3.5">
          <span className="hint">Похожие решённые тикеты — возможно, ответ уже есть:</span>
          {hits.map((h, i) => (
            <div key={i} className="mt-2"><b>{h.title}</b>{h.answer && <div className="hint">{h.answer.slice(0, 200)}</div>}</div>
          ))}
        </div>
      )}
    </>
  );
}
