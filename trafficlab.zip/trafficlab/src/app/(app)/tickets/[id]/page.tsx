import Link from "next/link";
import { notFound } from "next/navigation";
import { getMe } from "@/lib/auth";
import { Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { PRIORITY, STAFF, TICKET_STATUS, TICKET_TYPES } from "@/lib/constants";
import { ago, dur } from "@/lib/format";
import { isClosed, slaLeft } from "@/lib/sla";
import { postMessage, rateTicket, updateTicket } from "../actions";

const LABELS: Record<string, string> = {
  category: "Категория", platform: "Платформа", kind: "Тип", card_type: "Тип карты", currency: "Валюта", geo: "ГЕО", qty: "Количество",
  limit: "Лимит, $", topup: "Пополнение, $", bin: "BIN / банк", offer: "Оффер", format: "Формат", lang: "Язык", deadline: "Дедлайн",
  brief: "ТЗ / комментарий", refs: "Референсы", staff: "С кем", day: "День", slot: "Время", duration: "Минут", diary: "Сводка дневника",
};
const MACROS = [
  "Принял в работу, вернусь с ответом в течение SLA.",
  "Пришлите, пожалуйста, ссылку на кампанию, скриншот ошибки и время, когда это началось.",
  "Проблема решена. Если повторится — ответьте в этой ветке.",
];

export default async function TicketPage({ params }: { params: { id: string } }) {
  const { supabase, user, isStaff, isAdmin } = await getMe();
  const { data: t } = await supabase.from("tickets").select("*, profiles!tickets_user_id_fkey(full_name), offer_tests(id, source, geo, offers(name))").eq("id", params.id).single();
  if (!t) notFound();
  const { data: msgs } = await supabase.from("ticket_messages").select("*, profiles(full_name)").eq("ticket_id", t.id).order("created_at");
  const f = (t.fields ?? {}) as Record<string, string>;
  const author = t.anonymous && !isAdmin && t.user_id !== user.id ? "Аноним" : (t as any).profiles?.full_name;
  const l = slaLeft(t);
  const test: any = (t as any).offer_tests;

  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href={t.type === "ticket" ? "/tickets" : `/requests?type=${t.type}`}>← Назад</Link>
      <PageHead title={t.title} sub={`${author} · ${ago(t.created_at)}`}>
        <span className="pill">{TICKET_TYPES[t.type]}</span>
        <span className="pill-info">{TICKET_STATUS[t.status]}</span>
        {!isClosed(t) && (l === Infinity ? <span className="pill-ok">ответ дан</span> : l < 0 ? <span className="pill-bad">SLA просрочен на {dur(l)}</span> : <span className="pill">SLA: {dur(l)}</span>)}
      </PageHead>
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex min-w-0 flex-col gap-3">
          {Object.keys(f).some((k) => f[k]) && (
            <div className="card">
              {Object.entries(LABELS).filter(([k]) => f[k]).map(([k, label]) => (
                <div key={k} className="flex justify-between gap-4 border-b border-line py-1.5 last:border-0">
                  <span className="text-muted">{label}</span><span className="whitespace-pre-wrap text-right">{k === "staff" ? STAFF[f[k]] : f[k]}</span>
                </div>
              ))}
              {test && <div className="flex justify-between gap-4 py-1.5"><span className="text-muted">Тест</span><Link className="text-accent" href={`/tests/${test.id}`}>{test.offers?.name} · {test.source} · {test.geo}</Link></div>}
            </div>
          )}
          {(msgs ?? []).map((m: any) => (
            <div key={m.id} className={`rounded-lg border p-3 ${m.is_internal ? "border-transparent bg-warn-soft" : "border-line bg-panel"}`}>
              <div className="mb-1 text-xs text-muted">{m.is_staff ? `Поддержка · ${m.profiles?.full_name}` : author}{m.is_internal ? " · внутренняя заметка" : ""} · {ago(m.created_at)}</div>
              <div className="whitespace-pre-wrap">{m.body}</div>
            </div>
          ))}
          <form action={postMessage} className="card flex flex-col gap-3">
            <input type="hidden" name="ticket_id" value={t.id} />
            <Field label={isStaff ? "Ответ" : "Сообщение"}><textarea className="input min-h-[100px]" name="body" required /></Field>
            {isStaff && (
              <>
                <details className="text-[13px]"><summary className="cursor-pointer text-muted">Шаблоны ответов</summary>
                  <ul className="mt-2 flex flex-col gap-1">{MACROS.map((m) => <li key={m} className="rounded bg-sunk px-2 py-1">{m}</li>)}</ul>
                </details>
                <label className="flex items-center gap-2"><input type="checkbox" name="internal" /> Внутренняя заметка (автор не увидит)</label>
              </>
            )}
            <div><Submit>Отправить</Submit></div>
          </form>
        </div>
        <div className="flex flex-col gap-3">
          {isStaff && (
            <form action={updateTicket} className="card flex flex-col gap-3">
              <input type="hidden" name="ticket_id" value={t.id} />
              <Field label="Статус"><select className="input" name="status" defaultValue={t.status}>{Object.entries(TICKET_STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
              <Field label="Приоритет"><select className="input" name="priority" defaultValue={t.priority}>{Object.entries(PRIORITY).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></Field>
              <Submit className="btn">Обновить</Submit>
            </form>
          )}
          {isClosed(t) && t.user_id === user.id && (
            <form action={rateTicket} className="card flex flex-col gap-2">
              <input type="hidden" name="ticket_id" value={t.id} />
              <span className="hint">Оцените решение</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} name="csat" value={n} className={`text-2xl ${(t.csat ?? 0) >= n ? "text-warn" : "text-line"}`} aria-label={`${n} из 5`}>★</button>
                ))}
              </div>
            </form>
          )}
        </div>
      </div>
    </>
  );
}
