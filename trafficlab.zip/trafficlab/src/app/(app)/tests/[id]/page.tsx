import Link from "next/link";
import { notFound } from "next/navigation";
import { getMe } from "@/lib/auth";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { TEST_LABEL } from "@/lib/constants";
import { ago, money, pct, sumMetrics, tone } from "@/lib/format";
import { setTestStatus } from "../actions";

export default async function TestPage({ params, searchParams }: { params: { id: string }; searchParams: { error?: string } }) {
  const { supabase, user, isStaff } = await getMe();
  const { data: t } = await supabase.from("offer_tests").select("*, offers(id, name, payout, geo), profiles!offer_tests_user_id_fkey(full_name)").eq("id", params.id).single();
  if (!t) notFound();
  const o: any = t.offers;
  const own = t.user_id === user.id;
  const { data: diary } = await supabase.from("diary_entries").select("spend, revenue, clicks, leads")
    .eq("user_id", t.user_id).eq("offer_id", o.id).eq("source", t.source).gte("entry_date", t.created_at.slice(0, 10));
  const m = sumMetrics(diary ?? []);
  const stopHit = m.spend >= 2 * Number(o.payout) && m.leads === 0;

  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/tests">← Тесты</Link>
      <PageHead title={`${o.name}: ${t.source} · ${t.geo}`} sub={`${(t as any).profiles?.full_name} · создан ${ago(t.created_at)}`}>
        <span className="pill-info">{TEST_LABEL[t.status]}</span>
      </PageHead>
      <div className="flex max-w-3xl flex-col gap-4">
        <ErrorNote error={searchParams.error} />
        <div className="card grid gap-3 sm:grid-cols-2">
          <div><div className="hint">Ставка оффера</div>{money(Number(o.payout))}</div>
          <div><div className="hint">Бюджет теста</div><span className="font-mono">{money(Number(t.budget))}</span></div>
          <div className="sm:col-span-2"><div className="hint">Гипотеза</div><p className="whitespace-pre-wrap">{t.hypothesis}</p></div>
          <div className="sm:col-span-2"><div className="hint">Стоп-правило</div>{t.stop_rule}</div>
        </div>
        <div className="card">
          <div className="hint">Из дневника по этой связке</div>
          {m.spend ? (
            <div className="mt-1 flex flex-wrap justify-between gap-3">
              <span>Расход <b className="font-mono">{money(m.spend)}</b> из {money(Number(t.budget))}</span>
              <span>Лиды <b className="font-mono">{m.leads}</b></span>
              <span>Профит <b className={`font-mono ${tone(m.profit)}`}>{money(m.profit)}</b></span>
              <span>ROI <b className={`font-mono ${tone(m.roi)}`}>{pct(m.roi)}</b></span>
            </div>
          ) : <p className="mt-1 text-muted">Записей пока нет. Указывайте этот оффер и источник в дневнике — цифры подтянутся сюда.</p>}
          {stopHit && t.status === "running" && <p className="mt-2 text-neg">Сработало стоп-правило: потрачено 2× ставки без лида.</p>}
        </div>
        {t.conclusion && <div className="card"><div className="hint">Вывод</div><p className="whitespace-pre-wrap">{t.conclusion}</p></div>}

        {isStaff && t.status === "idea" && (
          <form action={setTestStatus} className="flex gap-2">
            <input type="hidden" name="id" value={t.id} />
            <Submit className="btn-good" name="status" value="approved">Одобрить</Submit>
            <Submit className="btn-bad" name="status" value="stopped">Отклонить</Submit>
          </form>
        )}
        {(own || isStaff) && t.status === "approved" && (
          <form action={setTestStatus} className="flex flex-wrap gap-2">
            <input type="hidden" name="id" value={t.id} />
            <Submit name="status" value="running">Запустил трафик</Submit>
            <Link className="btn" href={`/requests/new?type=accounts&test=${t.id}`}>Заказать аккаунты</Link>
            <Link className="btn" href={`/requests/new?type=cards&test=${t.id}`}>Заказать карты</Link>
            <Link className="btn" href={`/requests/new?type=creatives&test=${t.id}`}>Заказать креативы</Link>
          </form>
        )}
        {(own || isStaff) && t.status === "running" && (
          <form action={setTestStatus} className="card flex flex-col gap-3">
            <input type="hidden" name="id" value={t.id} />
            <Field label="Вывод теста" hint="Что узнали: какой креатив, время, CR, почему плюс или минус. Обязателен для «Плюс» и «Минус».">
              <textarea className="input min-h-[110px]" name="conclusion" />
            </Field>
            <div className="flex flex-wrap gap-2">
              <Submit className="btn-good" name="status" value="plus">Плюс</Submit>
              <Submit className="btn-bad" name="status" value="minus">Минус</Submit>
              <Submit className="btn" name="status" value="stopped">Остановить</Submit>
            </div>
          </form>
        )}
      </div>
    </>
  );
}
