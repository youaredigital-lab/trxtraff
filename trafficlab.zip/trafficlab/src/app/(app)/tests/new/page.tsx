import Link from "next/link";
import { getMe } from "@/lib/auth";
import { ErrorNote, Field, Lock, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { SOURCES, TRUST_LEVELS } from "@/lib/constants";
import { money } from "@/lib/format";
import { createTest } from "../actions";

export default async function NewTest({ searchParams }: { searchParams: { offer?: string; error?: string } }) {
  const { supabase, stats, isStaff } = await getMe();
  const { data: offers } = await supabase.from("offers").select("id, name, geo, payout").order("name");
  const o = offers?.find((x) => x.id === searchParams.offer) ?? offers?.[0];
  const locked = !isStaff && stats.trust_level < 2;
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/tests">← Тесты</Link>
      <PageHead title="Новый тест оффера" sub="Тест уходит тимлиду на одобрение. Без гипотезы и стоп-правила тест не стартует." />
      {locked ? (
        <Lock level={2} need={TRUST_LEVELS[2].need}>
          Пока можно <Link className="text-accent underline" href="/offers/propose">предложить оффер</Link> — тимлид может взять его в тест.
        </Lock>
      ) : !o ? (
        <p className="text-muted">В базе нет офферов.</p>
      ) : (
        <form action={createTest} className="card flex max-w-2xl flex-col gap-3.5">
          <ErrorNote error={searchParams.error} />
          <Field label="Оффер">
            <select className="input" name="offer_id" defaultValue={o.id}>
              {offers!.map((x) => <option key={x.id} value={x.id}>{x.name} · {x.geo} · {money(Number(x.payout))}</option>)}
            </select>
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Источник"><select className="input" name="source">{SOURCES.map((s) => <option key={s}>{s}</option>)}</select></Field>
            <Field label="ГЕО"><input className="input" name="geo" defaultValue={o.geo} required /></Field>
          </div>
          <Field label="Гипотеза" hint="Так команда понимает, что именно проверяем.">
            <textarea className="input" name="hypothesis" required minLength={10} placeholder="Если льём оффер с UGC-креативом «до/после» на женщин 35–55, то CR будет ≥ 3%" />
          </Field>
          <Field label="Тестовый бюджет, $" hint={`Рекомендуем ${money(Math.round(Number(o.payout) * 2))}–${money(Math.round(Number(o.payout) * 3))} для выбранного оффера: 2–3 ставки дают первый значимый сигнал.`}>
            <input className="input" name="budget" type="number" min="1" step="1" defaultValue={Math.round(Number(o.payout) * 2.5)} required />
          </Field>
          <Field label="Стоп-правило"><input className="input" name="stop_rule" defaultValue="Стоп при расходе 2× ставки без лида" required /></Field>
          <div><Submit>{isStaff ? "Создать тест" : "Отправить на одобрение"}</Submit></div>
        </form>
      )}
    </>
  );
}
