import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Chips, PageHead } from "@/components/ui";
import { TEST_STATUS } from "@/lib/constants";
import { money } from "@/lib/format";

export default async function Tests({ searchParams }: { searchParams: { mine?: string } }) {
  const { supabase, user } = await getMe();
  const mine = searchParams.mine === "1";
  let q = supabase.from("offer_tests").select("id, status, source, geo, budget, user_id, created_at, offers(name), profiles!offer_tests_user_id_fkey(full_name)").order("created_at", { ascending: false });
  if (mine) q = q.eq("user_id", user.id);
  const { data } = await q;

  return (
    <>
      <PageHead title="Тесты офферов" sub="Каждый запуск — гипотеза, бюджет и стоп-правило. Закрыть тест можно только с выводом: лучшие выводы становятся кейсами.">
        <Link className="btn" href="/offers/propose">Предложить оффер</Link>
        <Link className="btn-pri" href="/tests/new">Новый тест</Link>
      </PageHead>
      <div className="mb-3.5"><Chips current={mine ? "1" : "0"} hrefFor={(k) => `/tests?mine=${k}`} items={[["0", "Вся команда"], ["1", "Мои"]]} /></div>
      <div className="grid gap-2.5 overflow-x-auto pb-2 [grid-template-columns:repeat(6,minmax(180px,1fr))]">
        {TEST_STATUS.map(([k, label]) => {
          const col = (data ?? []).filter((t) => t.status === k);
          return (
            <div key={k} className="flex min-h-[140px] flex-col gap-2 rounded-card bg-sunk p-2.5">
              <h4 className="flex justify-between text-xs uppercase tracking-wider text-muted"><span>{label}</span><span>{col.length}</span></h4>
              {col.map((t: any) => (
                <Link key={t.id} href={`/tests/${t.id}`} className="flex flex-col gap-1 rounded-lg border border-line bg-panel p-2.5 text-[13px] hover:border-muted">
                  <b>{t.offers?.name}</b>
                  <span className="text-muted">{t.source} · {t.geo} · {money(Number(t.budget))}</span>
                  <span className="text-xs text-muted">{t.profiles?.full_name}</span>
                </Link>
              ))}
            </div>
          );
        })}
      </div>
    </>
  );
}
