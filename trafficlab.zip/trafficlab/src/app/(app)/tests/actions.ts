"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { num } from "@/lib/format";
import { notifyStaff, notifyUser } from "@/lib/telegram";

export async function createTest(fd: FormData) {
  const { supabase, profile, isStaff } = await getMe();
  const { data, error } = await supabase.from("offer_tests").insert({
    offer_id: String(fd.get("offer_id")),
    source: String(fd.get("source")),
    geo: String(fd.get("geo")).trim().toUpperCase(),
    hypothesis: String(fd.get("hypothesis")).trim(),
    budget: num(fd.get("budget")),
    stop_rule: String(fd.get("stop_rule")).trim(),
  }).select("id").single();
  if (error) redirect(`/tests/new?offer=${fd.get("offer_id")}&error=${encodeURIComponent(error.message)}`);
  if (!isStaff) await notifyStaff(`${profile.full_name} просит одобрить тест оффера`, `/tests/${data.id}`, ["teamlead", "admin"]);
  revalidatePath("/tests");
  redirect(`/tests/${data.id}`);
}

export async function setTestStatus(fd: FormData) {
  const { supabase } = await getMe();
  const id = String(fd.get("id"));
  const status = String(fd.get("status"));
  const patch: Record<string, unknown> = { status };
  const conclusion = String(fd.get("conclusion") ?? "").trim();
  if (conclusion) patch.conclusion = conclusion;
  const { data, error } = await supabase.from("offer_tests").update(patch).eq("id", id).select("user_id").single();
  if (error) redirect(`/tests/${id}?error=${encodeURIComponent(error.message)}`);
  if (status === "approved") await notifyUser(data.user_id, "Ваш тест оффера одобрен — можно запускать трафик", `/tests/${id}`);
  if (status === "stopped") await notifyUser(data.user_id, "Тест оффера остановлен", `/tests/${id}`);
  revalidatePath("/tests");
  redirect(`/tests/${id}`);
}
