import Link from "next/link";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { VideoUpload } from "@/components/VideoUpload";
import { MEETING_KIND, MEETING_VISIBILITY } from "@/lib/constants";
import { today } from "@/lib/format";
import { deleteMeeting, getUploadTicket, saveMeeting } from "../actions";

export function MeetingEditor({ meeting, tracks, error }: { meeting?: any; tracks: any[]; error?: string }) {
  const m = meeting ?? {};
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/meetings">← Записи митов</Link>
      <PageHead title={m.id ? "Редактировать запись" : "Загрузить запись мита"} sub="Файл загружается напрямую в хранилище. Для длинных записей удобнее ссылка на YouTube (по ссылке), Vimeo, Loom или Google Drive." />
      <form action={saveMeeting} className="card flex max-w-3xl flex-col gap-3.5">
        <ErrorNote error={error} />
        {m.id && <input type="hidden" name="id" value={m.id} />}
        <Field label="Название"><input className="input" name="title" required defaultValue={m.title} placeholder="Планёрка: итоги недели и новые офферы" /></Field>
        <div className="grid gap-3 sm:grid-cols-4">
          <Field label="Тип"><select className="input" name="kind" defaultValue={m.kind ?? "meeting"}>{Object.entries(MEETING_KIND).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field label="Кто видит"><select className="input" name="visibility" defaultValue={m.visibility ?? "all"}>{Object.entries(MEETING_VISIBILITY).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field label="Дата"><input className="input" name="recorded_at" type="date" defaultValue={m.recorded_at ?? today()} /></Field>
          <Field label="Длительность, мин"><input className="input" name="duration_min" type="number" min="1" defaultValue={m.duration_min ?? ""} /></Field>
        </div>
        <div className="flex flex-col gap-2 rounded-card border border-line p-3.5">
          <span className="text-[12.5px] font-medium text-muted">Видео</span>
          <VideoUpload name="video_path" folder="meetings" current={m.video_path} getTicket={getUploadTicket} />
          <Field label="или ссылка на запись"><input className="input" name="video_url" type="url" defaultValue={m.video_url ?? ""} placeholder="https://www.loom.com/share/…" /></Field>
        </div>
        <Field label="Описание и таймкоды" hint="Например: 00:00 итоги недели · 12:30 новый оффер · 25:10 вопросы"><textarea className="input min-h-[140px]" name="description" defaultValue={m.description} /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Связать с треком"><select className="input" name="track_id" defaultValue={m.track_id ?? ""}><option value="">—</option>{tracks.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></Field>
          <Field label="Теги через запятую"><input className="input" name="tags" defaultValue={(m.tags ?? []).join(", ")} placeholder="Nutra, Facebook" /></Field>
        </div>
        <div className="flex flex-wrap gap-2">
          <Submit>Сохранить</Submit>
          {m.id && <Submit className="btn-bad" formAction={deleteMeeting}>Удалить запись</Submit>}
        </div>
      </form>
    </>
  );
}
