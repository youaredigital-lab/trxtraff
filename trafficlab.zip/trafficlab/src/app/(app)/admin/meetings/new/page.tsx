import { requireAdmin } from "@/lib/auth";
import { MeetingEditor } from "../MeetingEditor";

export default async function NewMeeting({ searchParams }: { searchParams: { error?: string } }) {
  const { supabase } = await requireAdmin();
  const { data: tracks } = await supabase.from("tracks").select("id, title").order("position");
  return <MeetingEditor tracks={tracks ?? []} error={searchParams.error} />;
}
