import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { MeetingEditor } from "../MeetingEditor";

export default async function EditMeeting({ params, searchParams }: { params: { id: string }; searchParams: { error?: string } }) {
  const { supabase } = await requireAdmin();
  const [{ data: meeting }, { data: tracks }] = await Promise.all([
    supabase.from("meetings").select("*").eq("id", params.id).single(),
    supabase.from("tracks").select("id, title").order("position"),
  ]);
  if (!meeting) notFound();
  return <MeetingEditor meeting={meeting} tracks={tracks ?? []} error={searchParams.error} />;
}
