import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { PageHead, Table } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { ROLES } from "@/lib/constants";
import { money } from "@/lib/format";
import { setRole } from "./actions";

export default async function Admin() {
  const { supabase, user } = await requireAdmin();
  const [{ data: people }, { data: board }] = await Promise.all([
    supabase.from("profiles").select("id, full_name, role, created_at, telegram_chat_id").order("created_at", { ascending: false }),
    supabase.rpc("leaderboard", { p_limit: 500 }),
  ]);
  const stat = new Map((board ?? []).map((b: any) => [b.user_id, b]));
  return (
    <>
      <PageHead title="Админка" sub="Пользователи и роли, контент и офферы.">
        <Link className="btn" href="/admin/lessons">Уроки</Link>
        <Link className="btn" href="/admin/meetings/new">Загрузить мит</Link>
        <Link className="btn" href="/admin/offers">Офферы</Link>
      </PageHead>
      <Table>
        <thead><tr><th>Имя</th><th>Роль</th><th className="num">TL</th><th className="num">XP</th><th className="num">Профит 30 дн</th><th>Telegram</th><th>С нами с</th></tr></thead>
        <tbody>
          {(people ?? []).map((p) => {
            const s: any = stat.get(p.id);
            return (
              <tr key={p.id}>
                <td>{p.full_name}</td>
                <td>
                  {p.id === user.id ? ROLES[p.role] : (
                    <form action={setRole} className="flex items-center gap-1.5">
                      <input type="hidden" name="id" value={p.id} />
                      <select className="input w-40 py-1" name="role" defaultValue={p.role}>{Object.entries(ROLES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
                      <Submit className="btn btn-sm">OK</Submit>
                    </form>
                  )}
                </td>
                <td className="num">{s ? s.trust_level : "—"}</td>
                <td className="num">{s ? s.xp : "—"}</td>
                <td className="num">{s ? money(Number(s.profit_30d)) : "—"}</td>
                <td>{p.telegram_chat_id ? <span className="pill-ok">привязан</span> : <span className="pill">нет</span>}</td>
                <td>{new Date(p.created_at).toLocaleDateString("ru-RU")}</td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </>
  );
}
