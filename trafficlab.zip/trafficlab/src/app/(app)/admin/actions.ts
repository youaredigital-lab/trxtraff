"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { num } from "@/lib/format";
import { notifyUser } from "@/lib/telegram";

const s = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const lines = (v: string) => v.split("\n").map((x) => x.trim()).filter(Boolean);

/** Подписанная ссылка для прямой загрузки видео в бакет media. */
export async function getUploadTicket(folder: string, filename: string) {
  const { supabase } = await requireAdmin();
  const safe = filename.toLowerCase().replace(/[^a-z0-9.\-_]+/g, "-").slice(-80);
  const path = `${folder === "lessons" ? "lessons" : "meetings"}/${crypto.randomUUID()}-${safe}`;
  const { data, error } = await supabase.storage.from("media").createSignedUploadUrl(path);
  if (error || !data) return { error: error?.message ?? "Не удалось получить ссылку для загрузки" };
  return { path: data.path, signedUrl: data.signedUrl };
}

async function removeFile(supabase: any, path?: string | null) {
  if (path) await supabase.storage.from("media").remove([path]);
}

export async function saveLesson(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const row = {
    track_id: s(fd, "track_id"),
    position: num(fd.get("position")),
    title: s(fd, "title"),
    minutes: num(fd.get("minutes")) || 10,
    body: String(fd.get("body") ?? ""),
    hw_prompt: s(fd, "hw_prompt") || null,
    hw_rubric: lines(s(fd, "hw_rubric")),
    video_path: s(fd, "video_path") || null,
    video_url: s(fd, "video_url") || null,
    updated_at: new Date().toISOString(),
  };
  if (id) {
    const { data: old } = await supabase.from("lessons").select("video_path").eq("id", id).single();
    if (old?.video_path && old.video_path !== row.video_path) await removeFile(supabase, old.video_path);
  }
  const { data, error } = id
    ? await supabase.from("lessons").update(row).eq("id", id).select("id").single()
    : await supabase.from("lessons").insert(row).select("id").single();
  if (error) redirect(`/admin/lessons/${id || "new"}?error=${encodeURIComponent(error.message)}`);

  // Квиз: «Вопрос | вариант | *правильный | вариант»
  const quiz = lines(s(fd, "quiz")).map((line, i) => {
    const parts = line.split("|").map((x) => x.trim());
    const opts = parts.slice(1);
    const correct = Math.max(0, opts.findIndex((o) => o.startsWith("*")));
    return { lesson_id: data.id, position: i + 1, question: parts[0], options: opts.map((o) => o.replace(/^\*/, "")), correct };
  }).filter((q) => q.options.length >= 2);
  await supabase.from("quiz_questions").delete().eq("lesson_id", data.id);
  if (quiz.length) await supabase.from("quiz_questions").insert(quiz);

  revalidatePath("/learn");
  redirect(`/learn/${data.id}`);
}

export async function deleteLesson(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const { data } = await supabase.from("lessons").select("video_path").eq("id", id).single();
  await removeFile(supabase, data?.video_path);
  await supabase.from("lessons").delete().eq("id", id);
  revalidatePath("/learn");
  redirect("/admin/lessons");
}

export async function addTrack(fd: FormData) {
  const { supabase } = await requireAdmin();
  await supabase.from("tracks").insert({ title: s(fd, "title"), position: num(fd.get("position")) });
  revalidatePath("/admin/lessons");
}

export async function saveMeeting(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const row = {
    title: s(fd, "title"),
    description: String(fd.get("description") ?? ""),
    kind: s(fd, "kind"),
    visibility: s(fd, "visibility"),
    recorded_at: s(fd, "recorded_at"),
    duration_min: num(fd.get("duration_min")) || null,
    video_path: s(fd, "video_path") || null,
    video_url: s(fd, "video_url") || null,
    track_id: s(fd, "track_id") || null,
    tags: s(fd, "tags").split(",").map((x) => x.trim()).filter(Boolean),
  };
  if (!row.video_path && !row.video_url) redirect(`/admin/meetings/${id || "new"}?error=${encodeURIComponent("Загрузите видео или вставьте ссылку")}`);
  if (id) {
    const { data: old } = await supabase.from("meetings").select("video_path").eq("id", id).single();
    if (old?.video_path && old.video_path !== row.video_path) await removeFile(supabase, old.video_path);
  }
  const { data, error } = id
    ? await supabase.from("meetings").update(row).eq("id", id).select("id").single()
    : await supabase.from("meetings").insert(row).select("id").single();
  if (error) redirect(`/admin/meetings/${id || "new"}?error=${encodeURIComponent(error.message)}`);
  revalidatePath("/meetings");
  redirect(`/meetings/${data.id}`);
}

export async function deleteMeeting(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const { data } = await supabase.from("meetings").select("video_path").eq("id", id).single();
  await removeFile(supabase, data?.video_path);
  await supabase.from("meetings").delete().eq("id", id);
  revalidatePath("/meetings");
  redirect("/meetings");
}

export async function saveGroup(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const split = (v: string) => v.split(",").map((x) => x.trim()).filter(Boolean);
  const row = { vertical: s(fd, "vertical"), name: s(fd, "name"), sources: split(s(fd, "sources")), geos: split(s(fd, "geos")).map((x) => x.toUpperCase()), tips: s(fd, "tips") || null };
  if (id) await supabase.from("offer_groups").update(row).eq("id", id);
  else await supabase.from("offer_groups").insert(row);
  revalidatePath("/offers");
  redirect("/admin/offers");
}

export async function saveOffer(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const row = {
    group_id: s(fd, "group_id"), name: s(fd, "name"), network: s(fd, "network") || null, payout: num(fd.get("payout")),
    geo: s(fd, "geo").toUpperCase(), approve: s(fd, "approve") || null, cap: s(fd, "cap") || null,
    landing_url: s(fd, "landing_url") || null, is_private: fd.get("is_private") === "on",
  };
  if (id) await supabase.from("offers").update(row).eq("id", id);
  else await supabase.from("offers").insert(row);
  revalidatePath("/offers");
  redirect("/admin/offers");
}

export async function deleteOffer(fd: FormData) {
  const { supabase } = await requireAdmin();
  await supabase.from("offers").delete().eq("id", s(fd, "id"));
  revalidatePath("/offers");
  redirect("/admin/offers");
}

export async function setRole(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = s(fd, "id");
  const role = s(fd, "role");
  const { error } = await supabase.from("profiles").update({ role }).eq("id", id);
  if (!error) await notifyUser(id, `Ваша роль на платформе изменена: ${role}`);
  revalidatePath("/admin");
}
