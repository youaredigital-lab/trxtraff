import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { LessonEditor } from "../LessonEditor";

export default async function EditLesson({ params, searchParams }: { params: { id: string }; searchParams: { error?: string } }) {
  const { supabase } = await requireAdmin();
  const [{ data: lesson }, { data: tracks }, { data: quiz }] = await Promise.all([
    supabase.from("lessons").select("*").eq("id", params.id).single(),
    supabase.from("tracks").select("id, title").order("position"),
    supabase.rpc("admin_quiz", { p_lesson: params.id }),
  ]);
  if (!lesson) notFound();
  const quizText = (quiz ?? []).map((q: any) => [q.question, ...q.options.map((o: string, i: number) => (i === q.correct ? "*" : "") + o)].join(" | ")).join("\n");
  return <LessonEditor lesson={lesson} tracks={tracks ?? []} quizText={quizText} error={searchParams.error} />;
}
