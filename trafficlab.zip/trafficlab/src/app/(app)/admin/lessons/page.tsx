import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { PageHead, Table } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { addTrack } from "../actions";

export default async function AdminLessons() {
  const { supabase } = await requireAdmin();
  const [{ data: tracks }, { data: lessons }] = await Promise.all([
    supabase.from("tracks").select("*").order("position"),
    supabase.from("lessons").select("id, title, track_id, position, minutes, hw_prompt, video_path, video_url").order("position"),
  ]);
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/admin">← Админка</Link>
      <PageHead title="Уроки" sub="Видео, текст, квиз и ДЗ в каждом уроке."><Link className="btn-pri" href="/admin/lessons/new">Новый урок</Link></PageHead>
      <div className="flex flex-col gap-4">
        {(tracks ?? []).map((t) => (
          <div key={t.id} className="flex flex-col gap-2">
            <h2 className="font-display text-base font-medium">{t.title}</h2>
            <Table>
              <thead><tr><th className="num">#</th><th>Урок</th><th>Видео</th><th>ДЗ</th><th className="num">Мин</th></tr></thead>
              <tbody>
                {(lessons ?? []).filter((l) => l.track_id === t.id).map((l) => (
                  <tr key={l.id}>
                    <td className="num">{l.position}</td>
                    <td><Link className="text-accent" href={`/admin/lessons/${l.id}`}>{l.title}</Link></td>
                    <td>{l.video_path ? <span className="pill-ok">файл</span> : l.video_url ? <span className="pill-info">ссылка</span> : <span className="pill">нет</span>}</td>
                    <td>{l.hw_prompt ? "есть" : "—"}</td>
                    <td className="num">{l.minutes}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        ))}
        <form action={addTrack} className="card flex flex-wrap items-end gap-3">
          <label className="label flex-1"><span>Новый трек</span><input className="input" name="title" required placeholder="TikTok Ads" /></label>
          <label className="label w-28"><span>Порядок</span><input className="input" name="position" type="number" defaultValue={(tracks?.length ?? 0) + 1} /></label>
          <Submit className="btn">Добавить трек</Submit>
        </form>
      </div>
    </>
  );
}
