import Link from "next/link";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { VideoUpload } from "@/components/VideoUpload";
import { deleteLesson, getUploadTicket, saveLesson } from "../actions";

export function LessonEditor({ lesson, tracks, quizText, error }: { lesson?: any; tracks: any[]; quizText: string; error?: string }) {
  const l = lesson ?? {};
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/admin/lessons">← Уроки</Link>
      <PageHead title={l.id ? "Редактировать урок" : "Новый урок"} sub="Видео можно загрузить файлом или вставить ссылку YouTube, Vimeo, Loom или Google Drive." />
      <form action={saveLesson} className="card flex max-w-3xl flex-col gap-3.5">
        <ErrorNote error={error} />
        {l.id && <input type="hidden" name="id" value={l.id} />}
        <div className="grid gap-3 sm:grid-cols-[1fr_120px_120px]">
          <Field label="Трек"><select className="input" name="track_id" defaultValue={l.track_id}>{tracks.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></Field>
          <Field label="Порядок"><input className="input" name="position" type="number" defaultValue={l.position ?? 1} /></Field>
          <Field label="Минут"><input className="input" name="minutes" type="number" defaultValue={l.minutes ?? 15} /></Field>
        </div>
        <Field label="Название"><input className="input" name="title" required defaultValue={l.title} /></Field>
        <div className="flex flex-col gap-2 rounded-card border border-line p-3.5">
          <span className="text-[12.5px] font-medium text-muted">Видеоурок</span>
          <VideoUpload name="video_path" folder="lessons" current={l.video_path} getTicket={getUploadTicket} />
          <Field label="или ссылка на видео" hint="Если указаны и файл, и ссылка — показывается файл."><input className="input" name="video_url" type="url" defaultValue={l.video_url ?? ""} placeholder="https://youtu.be/…" /></Field>
        </div>
        <Field label="Текст урока" hint="Абзацы через пустую строку, **жирный** выделяется звёздочками."><textarea className="input min-h-[220px]" name="body" defaultValue={l.body} /></Field>
        <Field label="Квиз" hint="Одна строка — один вопрос: Вопрос | вариант | *правильный | вариант">
          <textarea className="input min-h-[120px] font-mono text-[13px]" name="quiz" defaultValue={quizText} placeholder="Расход $200, доход $300. ROI? | 150% | *50% | 33%" />
        </Field>
        <Field label="Задание ДЗ" hint="Оставьте пустым, если ДЗ нет."><textarea className="input" name="hw_prompt" defaultValue={l.hw_prompt ?? ""} /></Field>
        <Field label="Критерии оценки ДЗ" hint="По одному на строку."><textarea className="input" name="hw_rubric" defaultValue={(l.hw_rubric ?? []).join("\n")} /></Field>
        <div className="flex flex-wrap gap-2">
          <Submit>Сохранить</Submit>
          {l.id && <Submit className="btn-bad" formAction={deleteLesson}>Удалить урок</Submit>}
        </div>
      </form>
    </>
  );
}
