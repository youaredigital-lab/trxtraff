import { requireAdmin } from "@/lib/auth";
import { LessonEditor } from "../LessonEditor";

export default async function NewLesson({ searchParams }: { searchParams: { error?: string } }) {
  const { supabase } = await requireAdmin();
  const { data: tracks } = await supabase.from("tracks").select("id, title").order("position");
  return <LessonEditor tracks={tracks ?? []} quizText="" error={searchParams.error} />;
}
