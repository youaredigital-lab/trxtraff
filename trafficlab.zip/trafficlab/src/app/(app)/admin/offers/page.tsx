import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { Field, PageHead, Table } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { money } from "@/lib/format";
import { deleteOffer, saveGroup, saveOffer } from "../actions";

export default async function AdminOffers() {
  const { supabase } = await requireAdmin();
  const [{ data: groups }, { data: offers }] = await Promise.all([
    supabase.from("offer_groups").select("*").order("vertical"),
    supabase.from("offers").select("*").order("created_at", { ascending: false }),
  ]);
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/offers">← Офферы</Link>
      <PageHead title="Управление офферами" sub="Подгруппы и офферы. Приватные офферы видят только TL4 и команда." />
      <div className="flex flex-col gap-5">
        <Table>
          <thead><tr><th>Оффер</th><th>Подгруппа</th><th className="num">Ставка</th><th>ГЕО</th><th>Доступ</th><th></th></tr></thead>
          <tbody>
            {(offers ?? []).map((o) => {
              const g = groups?.find((x) => x.id === o.group_id);
              return (
                <tr key={o.id}>
                  <td>{o.name}</td><td>{g ? `${g.vertical} → ${g.name}` : "—"}</td><td className="num">{money(Number(o.payout))}</td><td>{o.geo}</td>
                  <td>{o.is_private ? <span className="pill-info">приватный</span> : "все"}</td>
                  <td><form action={deleteOffer}><input type="hidden" name="id" value={o.id} /><Submit className="btn-ghost btn-sm text-neg">Удалить</Submit></form></td>
                </tr>
              );
            })}
          </tbody>
        </Table>
        <div className="grid gap-4 lg:grid-cols-2">
          <form action={saveOffer} className="card flex flex-col gap-3">
            <h2 className="font-display text-base font-medium">Новый оффер</h2>
            <Field label="Подгруппа"><select className="input" name="group_id">{(groups ?? []).map((g) => <option key={g.id} value={g.id}>{g.vertical} → {g.name}</option>)}</select></Field>
            <Field label="Название"><input className="input" name="name" required /></Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Партнёрка"><input className="input" name="network" /></Field>
              <Field label="Ставка, $"><input className="input" name="payout" type="number" step="0.01" required /></Field>
              <Field label="ГЕО"><input className="input" name="geo" required /></Field>
              <Field label="Аппрув"><input className="input" name="approve" placeholder="45%" /></Field>
            </div>
            <Field label="Капа"><input className="input" name="cap" placeholder="50 лидов/день" /></Field>
            <Field label="Ссылка на лендинг"><input className="input" name="landing_url" type="url" /></Field>
            <label className="flex items-center gap-2"><input type="checkbox" name="is_private" /> Приватный (TL4 и команда)</label>
            <div><Submit>Добавить оффер</Submit></div>
          </form>
          <form action={saveGroup} className="card flex flex-col gap-3">
            <h2 className="font-display text-base font-medium">Новая подгруппа</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Вертикаль"><input className="input" name="vertical" required placeholder="Nutra" /></Field>
              <Field label="Подгруппа"><input className="input" name="name" required placeholder="Похудение" /></Field>
            </div>
            <Field label="Источники через запятую"><input className="input" name="sources" placeholder="Facebook, TikTok" /></Field>
            <Field label="ГЕО через запятую"><input className="input" name="geos" placeholder="PL, RO, IT" /></Field>
            <Field label="Подходы и советы"><textarea className="input" name="tips" /></Field>
            <div><Submit>Создать подгруппу</Submit></div>
          </form>
        </div>
      </div>
    </>
  );
}
