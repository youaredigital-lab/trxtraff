"use server";
import { revalidatePath } from "next/cache";
import { getMe } from "@/lib/auth";

export async function saveProfile(fd: FormData) {
  const { supabase, user } = await getMe();
  await supabase.from("profiles").update({ full_name: String(fd.get("full_name") ?? "").trim() }).eq("id", user.id);
  revalidatePath("/", "layout");
}
