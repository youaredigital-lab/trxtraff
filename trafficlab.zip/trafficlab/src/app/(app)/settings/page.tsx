import { getMe } from "@/lib/auth";
import { Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { ROLES, TRUST_LEVELS } from "@/lib/constants";
import { saveProfile } from "./actions";

export default async function Settings() {
  const { profile, stats, isStaff, user } = await getMe();
  const bot = process.env.NEXT_PUBLIC_TELEGRAM_BOT_NAME;
  return (
    <>
      <PageHead title="Профиль" sub={`${user.email} · ${ROLES[profile.role]}`} />
      <div className="grid max-w-4xl gap-4 lg:grid-cols-2">
        <form action={saveProfile} className="card flex flex-col gap-3">
          <h2 className="font-display text-base font-medium">Данные</h2>
          <Field label="Имя"><input className="input" name="full_name" defaultValue={profile.full_name} required /></Field>
          <div><Submit>Сохранить</Submit></div>
        </form>
        <div className="card flex flex-col gap-3">
          <h2 className="font-display text-base font-medium">Telegram-уведомления</h2>
          <p className="text-muted">Статусы ДЗ, ответы в тикетах, решения по заявкам и напоминание заполнить дневник в 21:00.</p>
          {profile.telegram_chat_id ? <span className="pill-ok w-fit">Telegram привязан</span> : bot ? (
            <a className="btn-pri w-fit" href={`https://t.me/${bot}?start=${profile.telegram_link_code}`} target="_blank" rel="noopener noreferrer">Привязать Telegram</a>
          ) : <span className="hint">Бот ещё не настроен администратором.</span>}
        </div>
        {!isStaff && (
          <div className="card flex flex-col gap-2 lg:col-span-2">
            <h2 className="font-display text-base font-medium">Уровни доверия</h2>
            {TRUST_LEVELS.map((t) => (
              <div key={t.n} className={`flex flex-wrap items-center justify-between gap-2 rounded-lg px-3 py-2 ${t.n === stats.trust_level ? "bg-accent-soft" : ""}`}>
                <span><b className="font-mono">TL{t.n}</b> · {t.name} <span className="text-muted">— {t.need}</span></span>
                <span className="text-[13px] text-muted">{t.gives}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
