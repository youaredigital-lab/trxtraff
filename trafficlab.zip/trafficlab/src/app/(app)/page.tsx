import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Kpi, PageHead } from "@/components/ui";
import { TRUST_LEVELS, TICKET_TYPES } from "@/lib/constants";
import { money, pct, tone, sumMetrics, daysAgo, today, dur } from "@/lib/format";
import { slaLeft, isClosed } from "@/lib/sla";

export default async function Dashboard() {
  const me = await getMe();
  return me.isStaff ? <StaffDash /> : <StudentDash />;
}

async function Leaderboard() {
  const { supabase, user } = await getMe();
  const { data } = await supabase.rpc("leaderboard", { p_limit: 6 });
  if (!data?.length) return <p className="text-muted">Рейтинг появится, когда ученики начнут проходить уроки.</p>;
  return (
    <div className="divide-y divide-line">
      {data.map((r: any, i: number) => (
        <div key={r.user_id} className="flex items-center justify-between gap-3 py-2.5">
          <span className="truncate"><span className="font-mono text-muted">{i + 1}.</span> {r.full_name}{r.user_id === user.id && <span className="pill-info ml-1">вы</span>}</span>
          <span className="flex items-center gap-2"><span className="pill">TL{r.trust_level}</span><span className="font-mono">{r.xp} XP</span></span>
        </div>
      ))}
    </div>
  );
}

async function StudentDash() {
  const { supabase, user, profile, stats } = await getMe();
  const tl = stats.trust_level;
  const next = TRUST_LEVELS[tl + 1];

  const [{ data: lessons }, { data: progress }, { data: diary }, { data: returned }, { data: running }, { count: openReq }] = await Promise.all([
    supabase.from("lessons").select("id, title, position, track_id, tracks(position)").order("position"),
    supabase.from("lesson_progress").select("lesson_id, completed_at").eq("user_id", user.id),
    supabase.from("diary_entries").select("entry_date, spend, revenue, clicks, leads").eq("user_id", user.id).gte("entry_date", daysAgo(30)),
    supabase.from("homework").select("id, lessons(title)").eq("user_id", user.id).eq("status", "returned").limit(1),
    supabase.from("offer_tests").select("id, offers(name)").eq("user_id", user.id).eq("status", "running").limit(1),
    supabase.from("tickets").select("id", { count: "exact", head: true }).eq("user_id", user.id).in("status", ["open", "progress", "waiting"]),
  ]);
  const done = new Set((progress ?? []).filter((p) => p.completed_at).map((p) => p.lesson_id));
  const ordered = (lessons ?? []).sort((a: any, b: any) => (a.tracks?.position ?? 0) - (b.tracks?.position ?? 0) || a.position - b.position);
  const nextLesson = ordered.find((l: any) => !done.has(l.id));
  const m = sumMetrics(diary ?? []);
  const wroteToday = (diary ?? []).some((d) => d.entry_date === today());

  const steps: [string, string, string][] = [];
  if (nextLesson) steps.push([`Пройти урок «${nextLesson.title}»`, `/learn/${nextLesson.id}`, "Открыть"]);
  if (returned?.[0]) steps.push([`Доработать ДЗ: ${(returned[0] as any).lessons?.title ?? ""}`, `/homework/${returned[0].id}`, "К ДЗ"]);
  if (tl >= 2 && !wroteToday) steps.push(["Записать результаты дня", "/diary/new", "Записать"]);
  if (running?.[0]) steps.push([`Подвести итог теста: ${(running[0] as any).offers?.name ?? ""}`, `/tests/${running[0].id}`, "Открыть"]);
  steps.push(["Нашли интересный оффер? Предложите его для теста", "/offers/propose", "Предложить"]);

  const lvlPct = tl === 0 ? Math.min(100, (stats.lessons_done / 3) * 100) : (tl / 4) * 100;

  return (
    <>
      <PageHead title={`Привет, ${profile.full_name}`} sub="Ваш путь от первого урока до стабильного плюса." />
      <div className="flex flex-col gap-4">
        <div className="card flex flex-wrap items-center gap-4">
          <div className="grid h-16 w-16 flex-none place-items-center rounded-2xl bg-accent font-display text-3xl font-bold text-accent-ink">{tl}</div>
          <div className="min-w-[220px] flex-1">
            <h2 className="font-display text-base font-medium">Trust Level {tl} · {TRUST_LEVELS[tl].name}</h2>
            <p className="mt-1 text-muted">
              {next ? <>Следующий уровень: <b className="text-ink">{next.name}</b> — {next.need}. Откроет: {next.gives}.</> : "Максимальный уровень доверия."}
            </p>
            <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-sunk"><span className="block h-full rounded-full bg-accent" style={{ width: `${Math.max(4, lvlPct)}%` }} /></div>
          </div>
          <div><div className="kpi-l">Опыт</div><div className="kpi-v">{stats.xp} XP</div></div>
        </div>
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(190px,1fr))]">
          <Kpi label="Профит за 30 дней" value={money(m.profit)} tone={tone(m.profit)} note={`Расход ${money(m.spend)}`} />
          <Kpi label="ROI за 30 дней" value={pct(m.roi)} tone={tone(m.roi)} note={`${stats.diary_count} записей в дневнике`} />
          <Kpi label="Уроков пройдено" value={`${stats.lessons_done} / ${lessons?.length ?? 0}`} note={`ДЗ принято: ${stats.hw_accepted}`} />
          <Kpi label="Открытые заявки" value={openReq ?? 0} note="Тикеты, аккаунты, карты, креативы" />
        </div>
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(320px,1fr))]">
          <div className="card">
            <h2 className="font-display text-base font-medium">Следующий шаг</h2>
            <div className="mt-2 divide-y divide-line">
              {steps.map(([t, href, cta]) => (
                <div key={href + t} className="flex items-center justify-between gap-3 py-2.5">
                  <span className="min-w-0 truncate">{t}</span>
                  <Link className="btn btn-sm" href={href}>{cta}</Link>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <h2 className="font-display text-base font-medium">Рейтинг потока</h2>
            <div className="mt-2"><Leaderboard /></div>
          </div>
        </div>
      </div>
    </>
  );
}

async function StaffDash() {
  const { supabase } = await getMe();
  const [{ data: hw }, { data: tickets }, { count: ideas }, { count: proposals }, { data: diary }] = await Promise.all([
    supabase.from("homework").select("id, created_at").eq("status", "submitted"),
    supabase.from("tickets").select("id, type, title, priority, status, created_at, first_response_at").in("status", ["open", "progress", "waiting"]),
    supabase.from("offer_tests").select("id", { count: "exact", head: true }).eq("status", "idea"),
    supabase.from("offer_proposals").select("id", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("diary_entries").select("spend, revenue, clicks, leads").gte("entry_date", daysAgo(30)),
  ]);
  const hwLate = (hw ?? []).filter((h) => Date.now() - Date.parse(h.created_at) > 48 * 36e5).length;
  const open = (tickets ?? []).filter((t) => !isClosed(t));
  const late = open.filter((t) => slaLeft(t) < 0).length;
  const team = sumMetrics(diary ?? []);
  const urgent = open.sort((a, b) => slaLeft(a) - slaLeft(b)).slice(0, 7);

  return (
    <>
      <PageHead title="Панель управления" sub="Очереди, просрочки и деньги команды на одном экране." />
      <div className="flex flex-col gap-4">
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(190px,1fr))]">
          <Kpi label="ДЗ на проверке" value={hw?.length ?? 0} tone={hwLate ? "text-warn" : ""} note={hwLate ? `${hwLate} дольше 48 ч` : "Все в срок"} />
          <Kpi label="Тикеты и заявки" value={open.length} tone={late ? "text-neg" : ""} note={late ? `${late} просрочено по SLA` : "SLA соблюдается"} />
          <Kpi label="Ждут решения" value={(ideas ?? 0) + (proposals ?? 0)} note={`Тесты: ${ideas ?? 0} · предложения офферов: ${proposals ?? 0}`} />
          <Kpi label="Профит команды, 30 дн" value={money(team.profit)} tone={tone(team.profit)} note={`ROI ${pct(team.roi)}`} />
        </div>
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(320px,1fr))]">
          <div className="card">
            <div className="flex items-center justify-between"><h2 className="font-display text-base font-medium">Горит по SLA</h2><Link className="btn-ghost btn-sm" href="/tickets">Вся очередь</Link></div>
            <div className="mt-2 divide-y divide-line">
              {urgent.length ? urgent.map((t) => {
                const l = slaLeft(t);
                return (
                  <Link key={t.id} href={`/tickets/${t.id}`} className="flex items-center justify-between gap-3 py-2.5 hover:text-accent">
                    <span className="min-w-0 truncate"><span className="pill mr-1">{TICKET_TYPES[t.type]}</span>{t.title}</span>
                    {l === Infinity ? <span className="pill-ok">ответ дан</span> : l < 0 ? <span className="pill-bad">−{dur(l)}</span> : <span className="pill">{dur(l)}</span>}
                  </Link>
                );
              }) : <p className="py-2 text-muted">Очередь пуста.</p>}
            </div>
          </div>
          <div className="card">
            <h2 className="font-display text-base font-medium">Рейтинг учеников</h2>
            <div className="mt-2"><Leaderboard /></div>
          </div>
        </div>
      </div>
    </>
  );
}
