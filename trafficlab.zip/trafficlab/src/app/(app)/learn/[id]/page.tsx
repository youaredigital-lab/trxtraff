import Link from "next/link";
import { notFound } from "next/navigation";
import { getMe } from "@/lib/auth";
import { aiEnabled } from "@/lib/ai";
import { Field, PageHead, Prose, ErrorNote } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { AiButton } from "@/components/AiButton";
import { Quiz } from "./Quiz";
import { VideoPlayer } from "@/components/VideoPlayer";
import { signedMedia } from "@/lib/media";
import { askTutor, completeLesson, hwPrecheck, reportOutdated, submitHomework } from "../actions";

const HW_PILL: Record<string, JSX.Element> = {
  submitted: <span className="pill-wait">На проверке</span>,
  accepted: <span className="pill-ok">Принято</span>,
  returned: <span className="pill-bad">На доработку</span>,
};

export default async function Lesson({ params, searchParams }: { params: { id: string }; searchParams: { error?: string; sent?: string; reported?: string } }) {
  const { supabase, user, isAdmin } = await getMe();
  const { data: l } = await supabase.from("lessons").select("*, tracks(title)").eq("id", params.id).single();
  if (!l) notFound();
  const [{ data: unlocked }, { data: questions }, { data: prog }, { data: hws }] = await Promise.all([
    supabase.rpc("lesson_unlocked", { p_uid: user.id, p_lesson: l.id }),
    supabase.from("quiz_questions").select("id, question, options, position").eq("lesson_id", l.id).order("position"),
    supabase.from("lesson_progress").select("*").eq("user_id", user.id).eq("lesson_id", l.id).maybeSingle(),
    supabase.from("homework").select("*").eq("user_id", user.id).eq("lesson_id", l.id).order("created_at", { ascending: false }).limit(1),
  ]);
  const hw = hws?.[0];
  const videoSrc = await signedMedia(supabase, l.video_path);
  const ai = aiEnabled();

  if (!unlocked) {
    return (
      <>
        <Link className="btn-ghost btn-sm mb-4" href="/learn">← Все уроки</Link>
        <PageHead title={l.title} sub="Урок откроется, когда вы пройдёте предыдущий урок трека." />
      </>
    );
  }

  return (
    <>
      <div className="mb-3.5 flex flex-wrap items-center gap-2">
        <Link className="btn-ghost btn-sm" href="/learn">← Все уроки</Link>
        <span className="pill">{(l as any).tracks?.title}</span>
        {prog?.completed_at && <span className="pill-ok">Пройден</span>}
      </div>
      <PageHead title={l.title} sub={`${l.minutes} мин · обновлено ${new Date(l.updated_at).toLocaleDateString("ru-RU", { month: "long", year: "numeric" })}`}>
        {isAdmin && <Link className="btn" href={`/admin/lessons/${l.id}`}>Редактировать</Link>}
      </PageHead>
      <div className="flex flex-col gap-4">
        <ErrorNote error={searchParams.error} />
        {(videoSrc || l.video_url) && <div className="max-w-4xl"><VideoPlayer src={videoSrc} url={l.video_url} title={l.title} /></div>}
        {l.body && <div className="card"><Prose text={l.body} /></div>}

        {questions?.length ? (
          <Quiz lessonId={l.id} questions={questions as any} best={prog?.quiz_score ?? null} />
        ) : !prog?.completed_at ? (
          <form action={completeLesson}><input type="hidden" name="lesson_id" value={l.id} /><Submit>Отметить пройденным</Submit></form>
        ) : null}

        {l.hw_prompt && (
          <div className="card flex flex-col gap-3">
            <div className="flex items-center justify-between"><h2 className="font-display text-base font-medium">Домашнее задание</h2>{hw && HW_PILL[hw.status]}</div>
            <p>{l.hw_prompt}</p>
            {!!l.hw_rubric?.length && <p className="hint">Критерии: {l.hw_rubric.join(" · ")}</p>}
            {hw?.comment && <div className="whitespace-pre-wrap rounded-lg border border-line p-3"><div className="text-xs text-muted">Комментарий куратора</div>{hw.comment}</div>}
            {searchParams.sent && <div className="rounded-lg bg-pos-soft px-3 py-2 text-pos">ДЗ отправлено куратору. Статус появится в разделе «Домашние задания».</div>}
            {(!hw || hw.status === "returned") && (
              <form id="hwform" action={submitHomework} className="flex flex-col gap-3">
                <input type="hidden" name="lesson_id" value={l.id} />
                <Field label="Ответ"><textarea className="input min-h-[140px]" name="answer" required minLength={10} placeholder="Опишите решение: связка, расчёты, выводы" /></Field>
                <Field label="Ссылка (скриншоты, таблица, креатив)"><input className="input" name="link" type="url" placeholder="https://" /></Field>
                {ai && <AiButton action={hwPrecheck} label="ИИ-предпроверка перед отправкой" formId="hwform" saveAs="ai_review" />}
                <div><Submit>{hw ? "Отправить исправленное" : "Отправить куратору"}</Submit></div>
              </form>
            )}
          </div>
        )}

        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(300px,1fr))]">
          {ai && (
            <form id="tutor" className="card flex flex-col gap-3">
              <h2 className="font-display text-base font-medium">ИИ-наставник</h2>
              <input type="hidden" name="lesson_id" value={l.id} />
              <Field label="Вопрос по уроку"><textarea className="input" name="question" placeholder="Почему ROI считают от расхода, а не от дохода?" /></Field>
              <AiButton action={askTutor} label="Спросить" formId="tutor" />
            </form>
          )}
          <form action={reportOutdated} className="card flex flex-col gap-3">
            <h2 className="font-display text-base font-medium">Материал устарел?</h2>
            <input type="hidden" name="lesson_id" value={l.id} /><input type="hidden" name="title" value={l.title} />
            <Field label="Что изменилось"><textarea className="input" name="note" placeholder="Например: в Ads Manager изменился интерфейс" /></Field>
            {searchParams.reported ? <span className="text-pos">Спасибо — автор урока получил тикет.</span> : <div><Submit className="btn">Сообщить автору</Submit></div>}
          </form>
        </div>
      </div>
    </>
  );
}
