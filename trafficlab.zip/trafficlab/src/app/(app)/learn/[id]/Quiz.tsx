"use client";
import { useState, useTransition } from "react";
import { submitQuiz } from "../actions";

type Q = { id: string; question: string; options: string[] };

export function Quiz({ lessonId, questions, best }: { lessonId: string; questions: Q[]; best: number | null }) {
  const [ans, setAns] = useState<Record<number, number>>({});
  const [res, setRes] = useState<{ right: number; total: number; passed: boolean; correct: number[] } | null>(null);
  const [err, setErr] = useState("");
  const [pending, start] = useTransition();
  const all = Object.keys(ans).length === questions.length;

  return (
    <div className="card flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-base font-medium">Квиз</h2>
        {best != null && <span className="pill-info">Лучший результат: {Math.round(best * 100)}%</span>}
      </div>
      {questions.map((q, qi) => (
        <fieldset key={q.id} className="flex flex-col gap-1 rounded-card border border-line p-3.5">
          <legend className="px-1 font-semibold">{qi + 1}. {q.question}</legend>
          {q.options.map((o, oi) => {
            const right = res && oi === res.correct[qi];
            const wrong = res && ans[qi] === oi && oi !== res.correct[qi];
            return (
              <label key={oi} className={`flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 hover:bg-sunk ${right ? "bg-pos-soft" : wrong ? "bg-neg-soft" : ""}`}>
                <input type="radio" name={`q${qi}`} disabled={!!res} checked={ans[qi] === oi} onChange={() => setAns({ ...ans, [qi]: oi })} />
                {o}
              </label>
            );
          })}
        </fieldset>
      ))}
      {err && <div className="rounded-card bg-neg-soft px-4 py-3 text-neg">{err}</div>}
      <div className="flex flex-wrap items-center gap-3">
        {res ? (
          <>
            <span>Результат: <b className="font-mono">{res.right}/{res.total}</b> — {res.passed ? <span className="text-pos">урок засчитан</span> : <span className="text-neg">меньше 50%, перечитайте урок</span>}</span>
            <button className="btn" onClick={() => { setRes(null); setAns({}); }}>Пройти заново</button>
          </>
        ) : (
          <button
            className="btn-pri"
            disabled={!all || pending}
            onClick={() => start(async () => {
              const r = await submitQuiz(lessonId, questions.map((_, i) => ans[i]));
              if ("error" in r && r.error) setErr(r.error); else if ("result" in r) setRes(r.result);
            })}
          >
            {pending ? "Проверяем…" : "Проверить ответы"}
          </button>
        )}
        <span className="hint">Урок засчитывается при 50%+ правильных ответов. Ответы проверяются на сервере.</span>
      </div>
    </div>
  );
}
