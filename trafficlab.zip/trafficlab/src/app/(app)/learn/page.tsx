import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Empty, PageHead } from "@/components/ui";

export default async function Learn() {
  const { supabase, user, isAdmin, isStaff } = await getMe();
  const [{ data: tracks }, { data: lessons }, { data: progress }] = await Promise.all([
    supabase.from("tracks").select("id, title, position").order("position"),
    supabase.from("lessons").select("id, track_id, position, title, minutes, hw_prompt, video_path, video_url").order("position"),
    supabase.from("lesson_progress").select("lesson_id, completed_at").eq("user_id", user.id),
  ]);
  const done = new Set((progress ?? []).filter((p) => p.completed_at).map((p) => p.lesson_id));

  return (
    <>
      <PageHead title="Обучение" sub="Треки открываются последовательно: теория, квиз и практическое ДЗ в каждом уроке.">
        {isAdmin && <Link className="btn-pri" href="/admin/lessons/new">Добавить урок</Link>}
      </PageHead>
      {!lessons?.length ? (
        <Empty title="Уроков пока нет">{isAdmin ? "Добавьте первый урок." : "Администратор скоро добавит программу."}</Empty>
      ) : (
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(260px,1fr))]">
          {(tracks ?? []).map((t) => {
            const ls = (lessons ?? []).filter((l) => l.track_id === t.id);
            if (!ls.length) return null;
            const d = ls.filter((l) => done.has(l.id)).length;
            return (
              <div key={t.id} className="card">
                <div className="flex items-center justify-between"><h3 className="font-semibold">{t.title}</h3><span className="font-mono text-muted">{d}/{ls.length}</span></div>
                <div className="my-2.5 h-2 overflow-hidden rounded-full bg-sunk"><span className="block h-full bg-accent" style={{ width: `${(d / ls.length) * 100}%` }} /></div>
                {ls.map((l, i) => {
                  const isDone = done.has(l.id);
                  const open = isStaff || i === 0 || done.has(ls[i - 1].id);
                  const inner = (
                    <>
                      <span className={`grid h-[22px] w-[22px] flex-none place-items-center rounded-full border-[1.5px] font-mono text-[11px] ${isDone ? "border-pos bg-pos text-white" : "border-line text-muted"}`}>{isDone ? "✓" : i + 1}</span>
                      <span className="min-w-0 flex-1">{l.title}<br /><span className="text-xs text-muted">{(l.video_path || l.video_url) ? "▶ видео · " : ""}{l.minutes} мин{l.hw_prompt ? " · ДЗ" : ""}</span></span>
                    </>
                  );
                  return open ? (
                    <Link key={l.id} href={`/learn/${l.id}`} className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 hover:bg-sunk">{inner}</Link>
                  ) : (
                    <div key={l.id} className="flex cursor-not-allowed items-center gap-2.5 rounded-lg px-2.5 py-2 opacity-50" title="Сначала пройдите предыдущий урок">{inner}</div>
                  );
                })}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
