"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { askClaude, aiEnabled } from "@/lib/ai";
import { notifyStaff } from "@/lib/telegram";

export async function submitQuiz(lessonId: string, answers: number[]) {
  const { supabase } = await getMe();
  const { data, error } = await supabase.rpc("submit_quiz", { p_lesson: lessonId, p_answers: answers });
  if (error) return { error: error.message };
  revalidatePath("/learn");
  revalidatePath(`/learn/${lessonId}`);
  return { result: data as { right: number; total: number; score: number; passed: boolean; correct: number[] } };
}

export async function completeLesson(fd: FormData) {
  const { supabase } = await getMe();
  const id = String(fd.get("lesson_id"));
  await supabase.rpc("complete_lesson", { p_lesson: id });
  revalidatePath(`/learn/${id}`);
}

export async function submitHomework(fd: FormData) {
  const { supabase, profile } = await getMe();
  const lessonId = String(fd.get("lesson_id"));
  const { error } = await supabase.from("homework").insert({
    lesson_id: lessonId,
    answer: String(fd.get("answer") ?? "").trim(),
    link: String(fd.get("link") ?? "").trim() || null,
    ai_review: String(fd.get("ai_review") ?? "").trim() || null,
  });
  if (error) redirect(`/learn/${lessonId}?error=${encodeURIComponent("Ответ слишком короткий или урок недоступен")}`);
  await notifyStaff(`Новое ДЗ на проверку от ${profile.full_name}`, "/homework");
  revalidatePath("/homework");
  redirect(`/learn/${lessonId}?sent=1`);
}

export async function reportOutdated(fd: FormData) {
  const { supabase } = await getMe();
  const id = String(fd.get("lesson_id"));
  const title = String(fd.get("title"));
  const { data } = await supabase.from("tickets").insert({ type: "ticket", title: `Урок устарел: ${title}`, category: "Обучение", priority: "low" }).select("id").single();
  if (data) await supabase.from("ticket_messages").insert({ ticket_id: data.id, body: String(fd.get("note") || "Материал урока выглядит устаревшим, прошу актуализировать.") });
  redirect(`/learn/${id}?reported=1`);
}

export async function hwPrecheck(fd: FormData) {
  if (!aiEnabled()) return { error: "ИИ-функции не настроены: добавьте ANTHROPIC_API_KEY." };
  const { supabase } = await getMe();
  const answer = String(fd.get("answer") ?? "");
  if (answer.trim().length < 20) return { error: "Сначала напишите ответ подробнее." };
  const { data: l } = await supabase.from("lessons").select("hw_prompt, hw_rubric").eq("id", String(fd.get("lesson_id"))).single();
  try {
    const text = await askClaude(
      `Ты куратор школы арбитража трафика. Проверь домашнее задание ученика по критериям. Ответь на русском, кратко: для каждого критерия оценка 0/1/2 с одной фразой пояснения, затем 2–3 конкретных совета. Без вступлений.\n\nЗадание: ${l?.hw_prompt}\nКритерии:\n- ${(l?.hw_rubric ?? []).join("\n- ")}\n\nОтвет ученика:\n${answer.slice(0, 6000)}`
    );
    return { text: text ?? "" };
  } catch {
    return { error: "ИИ сейчас не ответил, попробуйте ещё раз." };
  }
}

export async function askTutor(fd: FormData) {
  if (!aiEnabled()) return { error: "ИИ-функции не настроены: добавьте ANTHROPIC_API_KEY." };
  const { supabase } = await getMe();
  const q = String(fd.get("question") ?? "").trim();
  if (!q) return { error: "Напишите вопрос." };
  const { data: l } = await supabase.from("lessons").select("title, body").eq("id", String(fd.get("lesson_id"))).single();
  try {
    const text = await askClaude(
      `Ты наставник в школе арбитража трафика. Ответь ученику на русском, коротко и по делу, опираясь на урок. Если вопрос вне урока — ответь кратко и посоветуй создать тикет куратору.\n\nУрок «${l?.title}»:\n${(l?.body ?? "").slice(0, 8000)}\n\nВопрос: ${q}`,
      800
    );
    return { text: text ?? "" };
  } catch {
    return { error: "ИИ сейчас не ответил, попробуйте ещё раз." };
  }
}
