import Link from "next/link";
import { getMe } from "@/lib/auth";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { SOURCES } from "@/lib/constants";
import { proposeOffer } from "../actions";

export default async function Propose({ searchParams }: { searchParams: { error?: string } }) {
  const { supabase } = await getMe();
  const { data: groups } = await supabase.from("offer_groups").select("id, vertical, name").order("vertical");
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/offers">← Офферы</Link>
      <PageHead title="Предложить оффер для теста" sub="Нашли оффер в партнёрке или у конкурентов? Обоснуйте — тимлид рассмотрит и добавит в базу. Одобренное предложение даёт +75 XP." />
      <form action={proposeOffer} className="card flex max-w-2xl flex-col gap-3.5">
        <ErrorNote error={searchParams.error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Название оффера"><input className="input" name="name" required placeholder="SlimFit PL" /></Field>
          <Field label="Партнёрка"><input className="input" name="network" required placeholder="Название CPA-сети" /></Field>
          <Field label="Вертикаль"><input className="input" name="vertical" required list="verticals" placeholder="Nutra" /></Field>
          <Field label="Подгруппа (если подходит)">
            <select className="input" name="group_id" defaultValue="">
              <option value="">— новая / не знаю —</option>
              {(groups ?? []).map((g) => <option key={g.id} value={g.id}>{g.vertical} → {g.name}</option>)}
            </select>
          </Field>
          <Field label="Ставка, $"><input className="input" name="payout" type="number" step="0.01" min="0" required /></Field>
          <Field label="ГЕО"><input className="input" name="geo" required placeholder="PL" /></Field>
        </div>
        <datalist id="verticals">{Array.from(new Set((groups ?? []).map((g) => g.vertical))).map((v) => <option key={v} value={v} />)}</datalist>
        <Field label="Ссылка на оффер или промо"><input className="input" name="url" type="url" placeholder="https://" /></Field>
        <fieldset className="label">
          <span>Источники, из которых планируете лить</span>
          <div className="flex flex-wrap gap-3">{SOURCES.map((s) => <label key={s} className="flex items-center gap-1.5"><input type="checkbox" name="sources" value={s} /> {s}</label>)}</div>
        </fieldset>
        <Field label="Почему этот оффер стоит протестировать" hint="Аппрув, конкуренция, сезонность, что видели в спай-сервисах, какую связку планируете.">
          <textarea className="input min-h-[120px]" name="why" required minLength={20} />
        </Field>
        <label className="flex items-center gap-2"><input type="checkbox" name="wants_to_test" defaultChecked /> Хочу протестировать сам</label>
        <div><Submit>Отправить на рассмотрение</Submit></div>
      </form>
    </>
  );
}
