import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Empty, PageHead, Table } from "@/components/ui";
import { SOURCES } from "@/lib/constants";
import { money, pct, sumMetrics, tone } from "@/lib/format";

export default async function Offers({ searchParams }: { searchParams: { group?: string } }) {
  const { supabase, isAdmin } = await getMe();
  const [{ data: groups }, { data: offers }, { data: tests }, { data: diary }, { count: pending }] = await Promise.all([
    supabase.from("offer_groups").select("*").order("vertical").order("name"),
    supabase.from("offers").select("*").order("created_at"),
    supabase.from("offer_tests").select("offer_id, source, status"),
    supabase.from("diary_entries").select("offer_id, spend, revenue, clicks, leads").not("offer_id", "is", null),
    supabase.from("offer_proposals").select("id", { count: "exact", head: true }).eq("status", "pending"),
  ]);

  const head = (
    <PageHead title="Офферы" sub="Вертикаль → подгруппа → оффер. ROI считается по дневникам команды, а не по цифрам партнёрки.">
      <Link className="btn" href="/offers/proposals">Предложения{pending ? ` · ${pending}` : ""}</Link>
      <Link className="btn" href="/offers/propose">Предложить оффер</Link>
      {isAdmin && <Link className="btn" href="/admin/offers">Управление</Link>}
      <Link className="btn-pri" href="/tests/new">Запустить тест</Link>
    </PageHead>
  );
  if (!groups?.length) return <>{head}<Empty title="Офферов пока нет">{isAdmin ? "Создайте подгруппу и офферы в админке." : "Предложите первый оффер для теста."}</Empty></>;

  const g = groups.find((x) => x.id === searchParams.group) ?? groups[0];
  const verticals = Array.from(new Set(groups.map((x) => x.vertical)));
  const inGroup = (offers ?? []).filter((o) => o.group_id === g.id);

  return (
    <>
      {head}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          {verticals.map((v) => (
            <div key={v} className="flex flex-wrap items-center gap-2">
              <span className="min-w-[86px] text-xs uppercase tracking-wider text-muted">{v}</span>
              {groups.filter((x) => x.vertical === v).map((x) => (
                <Link key={x.id} href={`/offers?group=${x.id}`} className={x.id === g.id ? "chip-on" : "chip"}>
                  {x.name} · {(offers ?? []).filter((o) => o.group_id === x.id).length}
                </Link>
              ))}
            </div>
          ))}
        </div>
        <div className="card">
          <h2 className="font-display text-base font-medium">{g.vertical} → {g.name}</h2>
          <p className="mt-1 text-muted">Источники: {g.sources.join(", ") || "—"} · ГЕО: {g.geos.join(", ") || "—"}</p>
          {g.tips && <p className="mt-2">{g.tips}</p>}
        </div>
        {!inGroup.length ? <Empty title="В подгруппе нет офферов" /> : (
          <>
            <Table>
              <thead><tr><th>Оффер</th><th>Партнёрка</th><th className="num">Ставка</th><th>ГЕО</th><th className="num">Аппрув</th><th>Капа</th><th className="num">Тестов</th><th className="num">ROI команды</th><th></th></tr></thead>
              <tbody>
                {inGroup.map((o) => {
                  const m = sumMetrics((diary ?? []).filter((d) => d.offer_id === o.id));
                  return (
                    <tr key={o.id}>
                      <td><b>{o.name}</b>{o.is_private && <span className="pill-info ml-1">приватный</span>}{o.proposal_id && <span className="pill ml-1">от ученика</span>}</td>
                      <td>{o.network}</td>
                      <td className="num">{money(Number(o.payout))}</td>
                      <td>{o.geo}</td>
                      <td className="num">{o.approve ?? "—"}</td>
                      <td>{o.cap ?? "—"}</td>
                      <td className="num">{(tests ?? []).filter((t) => t.offer_id === o.id).length}</td>
                      <td className={`num ${m.spend ? tone(m.roi) : "text-muted"}`}>{m.spend ? pct(m.roi) : "нет данных"}</td>
                      <td><Link className="btn btn-sm" href={`/tests/new?offer=${o.id}`}>Тест</Link></td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
            <div className="card">
              <h2 className="font-display text-base font-medium">Карта протестированного</h2>
              <p className="mt-1 text-muted">Лучший результат по связке оффер × источник. Серое — никто не пробовал.</p>
              <div className="mt-3 overflow-x-auto">
                <table className="text-[13px]">
                  <thead><tr><th className="px-2 py-1 text-left font-medium text-muted">Оффер</th>{SOURCES.map((s) => <th key={s} className="px-2 py-1 font-medium text-muted">{s}</th>)}</tr></thead>
                  <tbody>
                    {inGroup.map((o) => (
                      <tr key={o.id}>
                        <td className="whitespace-nowrap px-2 py-1">{o.name}</td>
                        {SOURCES.map((s) => {
                          const ts = (tests ?? []).filter((t) => t.offer_id === o.id && t.source === s);
                          const st = ts.some((t) => t.status === "plus") ? "bg-pos" : ts.some((t) => ["running", "approved"].includes(t.status)) ? "bg-warn" : ts.some((t) => ["minus", "stopped"].includes(t.status)) ? "bg-neg" : "bg-sunk";
                          return <td key={s} className="px-2 py-1 text-center"><span className={`inline-block h-[18px] w-[26px] rounded ${st}`} /></td>;
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-2 flex flex-wrap gap-3 text-[12.5px] text-muted">
                <span><span className="mr-1 inline-block h-2.5 w-3 rounded-sm bg-pos" />плюс</span>
                <span><span className="mr-1 inline-block h-2.5 w-3 rounded-sm bg-warn" />в работе</span>
                <span><span className="mr-1 inline-block h-2.5 w-3 rounded-sm bg-neg" />минус / стоп</span>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
