import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Empty, ErrorNote, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { ago, money } from "@/lib/format";
import { approveProposal, deleteProposal, rejectProposal } from "../actions";

const ST: Record<string, JSX.Element> = {
  pending: <span className="pill-wait">На рассмотрении</span>,
  approved: <span className="pill-ok">Добавлен в базу</span>,
  rejected: <span className="pill-bad">Отклонён</span>,
};

export default async function Proposals({ searchParams }: { searchParams: { sent?: string; error?: string } }) {
  const { supabase, user, isStaff, isAdmin } = await getMe();
  let q = supabase.from("offer_proposals").select("*, profiles!offer_proposals_user_id_fkey(full_name), offer_groups(vertical, name)").order("created_at", { ascending: false });
  if (!isStaff) q = q.eq("user_id", user.id);
  const [{ data }, { data: groups }] = await Promise.all([q, supabase.from("offer_groups").select("id, vertical, name").order("vertical")]);

  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/offers">← Офферы</Link>
      <PageHead title="Предложения офферов" sub={isAdmin ? "Ученики предлагают офферы для тестов. Одобрение сразу добавляет оффер в базу." : "Ваши предложения и решения тимлида."}>
        <Link className="btn-pri" href="/offers/propose">Предложить оффер</Link>
      </PageHead>
      <div className="flex flex-col gap-3">
        {searchParams.sent && <div className="rounded-card bg-pos-soft px-4 py-3 text-pos">Предложение отправлено тимлиду.</div>}
        <ErrorNote error={searchParams.error} />
        {!data?.length && <Empty title="Предложений пока нет">Нашли интересный оффер — предложите его для теста.</Empty>}
        {(data ?? []).map((p: any) => (
          <div key={p.id} className="card flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <b>{p.name}</b><span className="text-muted">{p.network} · {p.vertical} · {p.geo} · {money(Number(p.payout))}</span>
              </div>
              {ST[p.status]}
            </div>
            <div className="text-[13px] text-muted">{p.profiles?.full_name} · {ago(p.created_at)}{p.sources?.length ? ` · ${p.sources.join(", ")}` : ""}{p.wants_to_test ? " · хочет тестировать сам" : ""}</div>
            <p className="whitespace-pre-wrap">{p.why}</p>
            {p.url && <a className="text-accent underline" href={p.url} target="_blank" rel="noopener noreferrer">{p.url}</a>}
            {p.admin_comment && <div className="rounded-lg border border-line p-3"><div className="text-xs text-muted">Комментарий тимлида</div>{p.admin_comment}</div>}
            {p.status === "approved" && p.offer_id && <div><Link className="btn btn-sm" href={`/tests/new?offer=${p.offer_id}`}>Запустить тест</Link></div>}
            {isAdmin && p.status === "pending" && (
              <form className="flex flex-col gap-2 border-t border-line pt-3">
                <input type="hidden" name="id" value={p.id} />
                <div className="grid gap-2 sm:grid-cols-2">
                  <select className="input" name="group_id" defaultValue={p.group_id ?? groups?.[0]?.id} required>
                    {(groups ?? []).map((g) => <option key={g.id} value={g.id}>{g.vertical} → {g.name}</option>)}
                  </select>
                  <input className="input" name="comment" placeholder="Комментарий автору" />
                </div>
                <div className="flex gap-2">
                  <Submit className="btn-good" formAction={approveProposal}>Одобрить и добавить</Submit>
                  <Submit className="btn-bad" formAction={rejectProposal}>Отклонить</Submit>
                </div>
              </form>
            )}
            {!isAdmin && p.user_id === user.id && p.status === "pending" && (
              <form action={deleteProposal}><input type="hidden" name="id" value={p.id} /><Submit className="btn-ghost btn-sm">Отозвать</Submit></form>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
