"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { notifyStaff, notifyUser } from "@/lib/telegram";
import { num } from "@/lib/format";

const list = (v: FormDataEntryValue | null) => String(v ?? "").split(",").map((x) => x.trim()).filter(Boolean);

export async function proposeOffer(fd: FormData) {
  const { supabase, profile } = await getMe();
  const sources = fd.getAll("sources").map(String);
  const { error } = await supabase.from("offer_proposals").insert({
    name: String(fd.get("name")).trim(),
    network: String(fd.get("network")).trim(),
    url: String(fd.get("url") ?? "").trim() || null,
    vertical: String(fd.get("vertical")).trim(),
    group_id: String(fd.get("group_id") ?? "") || null,
    payout: num(fd.get("payout")),
    geo: String(fd.get("geo")).trim().toUpperCase(),
    sources,
    why: String(fd.get("why")).trim(),
    wants_to_test: fd.get("wants_to_test") === "on",
  });
  if (error) redirect(`/offers/propose?error=${encodeURIComponent("Заполните все поля. Обоснование — от 20 символов.")}`);
  await notifyStaff(`${profile.full_name} предложил оффер «${fd.get("name")}» для теста`, "/offers/proposals", ["teamlead", "admin"]);
  revalidatePath("/offers/proposals");
  redirect("/offers/proposals?sent=1");
}

export async function approveProposal(fd: FormData) {
  const { supabase, isAdmin } = await getMe();
  if (!isAdmin) redirect("/offers/proposals");
  const id = String(fd.get("id"));
  const { data: offerId, error } = await supabase.rpc("approve_proposal", {
    p_id: id,
    p_group: String(fd.get("group_id")),
    p_comment: String(fd.get("comment") ?? "").trim() || null,
  });
  if (error) redirect(`/offers/proposals?error=${encodeURIComponent(error.message)}`);
  const { data: p } = await supabase.from("offer_proposals").select("user_id, name").eq("id", id).single();
  if (p) await notifyUser(p.user_id, `Ваш оффер «${p.name}» добавлен в базу. +75 XP. Можно запускать тест.`, `/tests/new?offer=${offerId}`);
  revalidatePath("/offers");
  redirect("/offers/proposals");
}

export async function rejectProposal(fd: FormData) {
  const { supabase, isAdmin } = await getMe();
  if (!isAdmin) redirect("/offers/proposals");
  const id = String(fd.get("id"));
  const comment = String(fd.get("comment") ?? "").trim();
  const { data: p } = await supabase.from("offer_proposals").update({ status: "rejected", admin_comment: comment || null }).eq("id", id).select("user_id, name").single();
  if (p) await notifyUser(p.user_id, `Оффер «${p.name}» не взяли в тест${comment ? `: ${comment}` : ""}`, "/offers/proposals");
  revalidatePath("/offers/proposals");
  redirect("/offers/proposals");
}

export async function deleteProposal(fd: FormData) {
  const { supabase } = await getMe();
  await supabase.from("offer_proposals").delete().eq("id", String(fd.get("id")));
  revalidatePath("/offers/proposals");
  redirect("/offers/proposals");
}
