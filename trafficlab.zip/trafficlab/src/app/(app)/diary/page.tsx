import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Chips, Empty, Kpi, PageHead, Table } from "@/components/ui";
import { AiButton } from "@/components/AiButton";
import { aiEnabled } from "@/lib/ai";
import { dateShort, daysAgo, metrics, money, pct, sumMetrics, today, tone } from "@/lib/format";
import { analyzeDiary, setGoal } from "./actions";
import { Submit } from "@/components/Submit";

function ProfitChart({ entries, range }: { entries: any[]; range: number }) {
  const by: Record<string, number> = {};
  entries.forEach((e) => { by[e.entry_date] = (by[e.entry_date] ?? 0) + metrics(e).profit; });
  const days = Array.from({ length: range }, (_, i) => daysAgo(range - 1 - i));
  const W = 720, H = 200, pl = 56, pr = 10, pt = 12, pb = 26;
  const mx = Math.max(10, ...days.map((d) => Math.abs(by[d] ?? 0)));
  const y = (v: number) => pt + (H - pt - pb) / 2 - (v / mx) * ((H - pt - pb) / 2);
  const bw = (W - pl - pr) / days.length;
  const step = Math.ceil(days.length / 8);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="block h-auto w-full" role="img" aria-label="Профит по дням">
      {[mx, mx / 2, 0, -mx / 2, -mx].map((v) => (
        <g key={v}>
          <line x1={pl} x2={W - pr} y1={y(v)} y2={y(v)} stroke="rgb(var(--line))" />
          <text x={pl - 6} y={y(v) + 4} textAnchor="end" fontSize="10.5" fill="rgb(var(--muted))" fontFamily="var(--font-mono)">{v === 0 ? "$0" : money(Math.round(v))}</text>
        </g>
      ))}
      {days.map((d, i) => {
        const x = pl + i * bw + bw * 0.15, w = bw * 0.7, val = by[d];
        return (
          <g key={d}>
            {val !== undefined && (
              <rect x={x} y={Math.min(y(0), y(val))} width={w} height={Math.max(1.5, Math.abs(y(val) - y(0)))} rx="2" fill={`rgb(var(--${val >= 0 ? "pos" : "neg"}))`}>
                <title>{`${dateShort(d)}: ${money(val)}`}</title>
              </rect>
            )}
            {i % step === 0 && <text x={x + w / 2} y={H - 8} textAnchor="middle" fontSize="10.5" fill="rgb(var(--muted))">{dateShort(d)}</text>}
          </g>
        );
      })}
    </svg>
  );
}

export default async function Diary({ searchParams }: { searchParams: { range?: string; user?: string } }) {
  const { supabase, user, isStaff, profile } = await getMe();
  const range = [7, 14, 30, 90].includes(Number(searchParams.range)) ? Number(searchParams.range) : 14;
  const who = isStaff ? searchParams.user ?? "" : user.id;

  let q = supabase.from("diary_entries").select("*, offers(name), profiles!diary_entries_user_id_fkey(full_name)").gte("entry_date", daysAgo(Math.max(range, 31))).order("entry_date", { ascending: false }).order("created_at", { ascending: false });
  if (who) q = q.eq("user_id", who);
  const [{ data: all }, buyersRes] = await Promise.all([
    q,
    isStaff ? supabase.from("profiles").select("id, full_name").in("role", ["student", "buyer"]).order("full_name") : Promise.resolve({ data: [] as any[] }),
  ]);
  const buyers = buyersRes.data ?? [];
  const entries = (all ?? []).filter((e) => e.entry_date >= daysAgo(range - 1));
  const s = sumMetrics(entries);
  const month = sumMetrics((all ?? []).filter((e) => e.entry_date.slice(0, 7) === today().slice(0, 7) && (!isStaff || e.user_id === who)));
  const last3 = (all ?? []).slice(0, 3);
  const tilt = !isStaff && last3.length === 3 && last3.every((e) => metrics(e).profit < 0);
  const goal = Number(profile.monthly_goal ?? 0);
  const qs = (o: Record<string, string | number>) => "/diary?" + new URLSearchParams({ range: String(range), user: who, ...Object.fromEntries(Object.entries(o).map(([k, v]) => [k, String(v)])) }).toString();

  return (
    <>
      <PageHead title="Дневник медиабайера" sub={isStaff ? "Дневники команды: динамика и комментарии к дням." : "Расход, доход, клики и лиды — остальное посчитается само."}>
        {!isStaff && <Link className="btn-pri" href="/diary/new">Записать день</Link>}
      </PageHead>
      <div className="flex flex-col gap-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Chips current={String(range)} hrefFor={(k) => qs({ range: k })} items={[["7", "7 дн"], ["14", "14 дн"], ["30", "30 дн"], ["90", "90 дн"]]} />
          {isStaff && (
            <form className="flex items-center gap-2" action="/diary">
              <input type="hidden" name="range" value={range} />
              <select className="input w-56" name="user" defaultValue={who}>
                <option value="">Вся команда</option>
                {buyers.map((b: any) => <option key={b.id} value={b.id}>{b.full_name}</option>)}
              </select>
              <button className="btn">Показать</button>
            </form>
          )}
          {!isStaff && (
            <form action={setGoal} className="flex min-w-[280px] max-w-md flex-1 items-center gap-2">
              <div className="flex-1">
                <div className="flex justify-between text-[12.5px]"><span className="text-muted">Цель месяца</span><span className="font-mono">{goal ? `${money(month.profit)} / ${money(goal)}` : "не задана"}</span></div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-sunk"><span className="block h-full bg-accent" style={{ width: `${goal ? Math.max(0, Math.min(100, (month.profit / goal) * 100)) : 0}%` }} /></div>
              </div>
              <input className="input w-24" name="goal" type="number" min="0" placeholder="$3000" defaultValue={goal || ""} />
              <Submit className="btn btn-sm">OK</Submit>
            </form>
          )}
        </div>
        {tilt && (
          <div className="rounded-card bg-neg-soft px-4 py-3">
            <b>Три минусовых дня подряд.</b> Остановитесь, пересмотрите связки и запишитесь на созвон с куратором, прежде чем доливать бюджет.{" "}
            <Link className="btn btn-sm" href="/requests/new?type=call">Записаться</Link>
          </div>
        )}
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(190px,1fr))]">
          <Kpi label="Профит" value={money(s.profit)} tone={tone(s.profit)} note={`Доход ${money(s.rev)}`} />
          <Kpi label="ROI" value={pct(s.roi)} tone={tone(s.roi)} note={`Расход ${money(s.spend)}`} />
          <Kpi label="Лиды" value={s.leads} note={`CPL ${Number.isFinite(s.cpl) ? money(s.cpl) : "—"}`} />
          <Kpi label="CR / EPC" value={Number.isFinite(s.cr) ? s.cr.toFixed(1) + "%" : "—"} note={`EPC ${Number.isFinite(s.epc) ? "$" + s.epc.toFixed(2) : "—"}`} />
        </div>
        {aiEnabled() && (
          <form id="aidiary">
            <input type="hidden" name="range" value={range} /><input type="hidden" name="user" value={who} />
            <AiButton action={analyzeDiary} label="ИИ-разбор периода" formId="aidiary" />
          </form>
        )}
        {!entries.length ? (
          <Empty title={isStaff ? "За период записей нет" : "Первая запись займёт минуту"}>{isStaff ? "Записи появятся, когда байеры начнут вести дневник." : "Нажмите «Записать день» — метрики посчитаются автоматически."}</Empty>
        ) : (
          <>
            <div className="card"><h2 className="mb-2 font-display text-base font-medium">Профит по дням</h2><ProfitChart entries={entries} range={range} /></div>
            <Table>
              <thead><tr><th>Дата</th>{isStaff && !who && <th>Байер</th>}<th>Оффер</th><th>Источник</th><th>ГЕО</th><th className="num">Расход</th><th className="num">Доход</th><th className="num">Профит</th><th className="num">ROI</th><th className="num">CR</th><th className="num">EPC</th><th>Куратор</th></tr></thead>
              <tbody>
                {entries.map((e: any) => {
                  const m = metrics(e);
                  return (
                    <tr key={e.id} className="cursor-pointer hover:bg-sunk">
                      <td><Link className="text-accent" href={`/diary/${e.id}`}>{dateShort(e.entry_date)}</Link></td>
                      {isStaff && !who && <td>{e.profiles?.full_name}</td>}
                      <td>{e.offers?.name ?? "—"}</td><td>{e.source}</td><td>{e.geo}</td>
                      <td className="num">{money(m.spend)}</td><td className="num">{money(m.rev)}</td>
                      <td className={`num ${tone(m.profit)}`}>{money(m.profit)}</td>
                      <td className={`num ${tone(m.roi)}`}>{pct(m.roi)}</td>
                      <td className="num">{Number.isFinite(m.cr) ? m.cr.toFixed(1) + "%" : "—"}</td>
                      <td className="num">{Number.isFinite(m.epc) ? "$" + m.epc.toFixed(2) : "—"}</td>
                      <td>{e.curator_comment ? <span className="pill-info">есть отзыв</span> : ""}</td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </>
        )}
      </div>
    </>
  );
}
