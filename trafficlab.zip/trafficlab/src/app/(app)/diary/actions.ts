"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { num, metrics, daysAgo } from "@/lib/format";
import { askClaude, aiEnabled } from "@/lib/ai";
import { notifyUser } from "@/lib/telegram";

function entryFrom(fd: FormData) {
  return {
    entry_date: String(fd.get("entry_date")),
    offer_id: String(fd.get("offer_id") ?? "") || null,
    source: String(fd.get("source")),
    geo: String(fd.get("geo") ?? "").trim().toUpperCase(),
    spend: num(fd.get("spend")),
    revenue: num(fd.get("revenue")),
    clicks: Math.round(num(fd.get("clicks"))),
    leads: Math.round(num(fd.get("leads"))),
    mood: Number(fd.get("mood") ?? 3),
    worked: String(fd.get("worked") ?? "").trim() || null,
    failed: String(fd.get("failed") ?? "").trim() || null,
    plan: String(fd.get("plan") ?? "").trim() || null,
  };
}

export async function saveEntry(fd: FormData) {
  const { supabase } = await getMe();
  const id = String(fd.get("id") ?? "");
  const row = entryFrom(fd);
  const { error } = id ? await supabase.from("diary_entries").update(row).eq("id", id) : await supabase.from("diary_entries").insert(row);
  if (error) redirect(`/diary/${id || "new"}?error=${encodeURIComponent(error.message)}`);
  revalidatePath("/diary");
  redirect("/diary");
}

export async function deleteEntry(fd: FormData) {
  const { supabase } = await getMe();
  await supabase.from("diary_entries").delete().eq("id", String(fd.get("id")));
  revalidatePath("/diary");
  redirect("/diary");
}

export async function commentEntry(fd: FormData) {
  const { supabase } = await getMe();
  const id = String(fd.get("id"));
  const { data } = await supabase.from("diary_entries").update({ curator_comment: String(fd.get("curator_comment") ?? "").trim() || null }).eq("id", id).select("user_id, entry_date").single();
  if (data) await notifyUser(data.user_id, `Куратор прокомментировал ваш день ${data.entry_date}`, `/diary/${id}`);
  revalidatePath("/diary");
  redirect(`/diary?user=${data?.user_id ?? ""}`);
}

export async function setGoal(fd: FormData) {
  const { supabase, user } = await getMe();
  await supabase.from("profiles").update({ monthly_goal: num(fd.get("goal")) || null }).eq("id", user.id);
  revalidatePath("/diary");
}

export async function analyzeDiary(fd: FormData) {
  if (!aiEnabled()) return { error: "ИИ-функции не настроены: добавьте ANTHROPIC_API_KEY." };
  const { supabase, user, isStaff } = await getMe();
  const range = Number(fd.get("range") ?? 14);
  const who = isStaff ? String(fd.get("user") ?? "") : user.id;
  let q = supabase.from("diary_entries").select("*, offers(name)").gte("entry_date", daysAgo(range)).order("entry_date", { ascending: false }).limit(80);
  if (who) q = q.eq("user_id", who);
  const { data } = await q;
  if (!data?.length) return { error: "За период нет записей." };
  const rows = data.map((e: any) => {
    const m = metrics(e);
    return [e.entry_date, e.offers?.name ?? "-", e.source, e.geo, `spend ${m.spend}`, `rev ${m.rev}`, `leads ${m.leads}`,
      `roi ${Number.isFinite(m.roi) ? m.roi.toFixed(0) + "%" : "-"}`, `mood ${e.mood}`, `worked: ${e.worked ?? "-"}`, `failed: ${e.failed ?? "-"}`].join("; ");
  }).join("\n");
  try {
    const text = await askClaude(
      `Ты тимлид арбитражной команды. Разбери дневник медиабайера за ${range} дней. На русском, без вступлений: 1) итог в одном предложении с цифрами; 2) лучшие и худшие связки (оффер × источник × ГЕО) с ROI; 3) куда утекает бюджет; 4) три конкретных действия на следующую неделю; 5) если видна связь настроения и результата — одно наблюдение.\n\nЗаписи:\n${rows}`,
      1500
    );
    return { text: text ?? "" };
  } catch {
    return { error: "ИИ сейчас не ответил, попробуйте ещё раз." };
  }
}
