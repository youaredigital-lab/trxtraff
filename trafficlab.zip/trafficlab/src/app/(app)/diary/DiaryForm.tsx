"use client";
import { useState } from "react";
import { metrics, money, pct } from "@/lib/format";
import { SOURCES } from "@/lib/constants";
import { Submit } from "@/components/Submit";

export function DiaryForm({ action, offers, entry, today }: { action: (fd: FormData) => Promise<void>; offers: { id: string; name: string; geo: string }[]; entry?: any; today: string }) {
  const e = entry ?? {};
  const [v, setV] = useState({ spend: e.spend ?? "", revenue: e.revenue ?? "", clicks: e.clicks ?? "", leads: e.leads ?? "" });
  const m = metrics(v);
  const set = (k: string) => (ev: React.ChangeEvent<HTMLInputElement>) => setV({ ...v, [k]: ev.target.value });
  const tone = (x: number) => (x > 0 ? "text-pos" : x < 0 ? "text-neg" : "");
  return (
    <form action={action} className="card flex max-w-2xl flex-col gap-3.5">
      {e.id && <input type="hidden" name="id" value={e.id} />}
      <label className="label"><span>Оффер</span>
        <select className="input" name="offer_id" defaultValue={e.offer_id ?? ""}>
          <option value="">— другой —</option>
          {offers.map((o) => <option key={o.id} value={o.id}>{o.name} · {o.geo}</option>)}
        </select>
      </label>
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="label"><span>Дата</span><input className="input" type="date" name="entry_date" defaultValue={e.entry_date ?? today} required /></label>
        <label className="label"><span>Источник</span><select className="input" name="source" defaultValue={e.source}>{SOURCES.map((s) => <option key={s}>{s}</option>)}</select></label>
        <label className="label"><span>ГЕО</span><input className="input" name="geo" defaultValue={e.geo} placeholder="PL" /></label>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="label"><span>Расход, $</span><input className="input" name="spend" type="number" step="0.01" min="0" value={v.spend} onChange={set("spend")} /></label>
        <label className="label"><span>Доход, $</span><input className="input" name="revenue" type="number" step="0.01" min="0" value={v.revenue} onChange={set("revenue")} /></label>
        <label className="label"><span>Клики</span><input className="input" name="clicks" type="number" min="0" value={v.clicks} onChange={set("clicks")} /></label>
        <label className="label"><span>Лиды / депозиты</span><input className="input" name="leads" type="number" min="0" value={v.leads} onChange={set("leads")} /></label>
      </div>
      <div className="flex flex-wrap justify-between gap-3 rounded-card bg-sunk p-3.5">
        <span>Профит <b className={`font-mono ${tone(m.profit)}`}>{money(m.profit)}</b></span>
        <span>ROI <b className={`font-mono ${tone(m.roi)}`}>{pct(m.roi)}</b></span>
        <span>CPL <b className="font-mono">{Number.isFinite(m.cpl) ? money(m.cpl) : "—"}</b></span>
        <span>CR <b className="font-mono">{Number.isFinite(m.cr) ? m.cr.toFixed(1) + "%" : "—"}</b></span>
        <span>EPC <b className="font-mono">{Number.isFinite(m.epc) ? "$" + m.epc.toFixed(2) : "—"}</b></span>
      </div>
      <label className="label"><span>Настроение дня</span>
        <select className="input" name="mood" defaultValue={String(e.mood ?? 3)}>
          <option value="5">5 — отлично</option><option value="4">4</option><option value="3">3 — нормально</option><option value="2">2</option><option value="1">1 — тяжёлый день</option>
        </select>
      </label>
      <label className="label"><span>Что сработало</span><textarea className="input" name="worked" defaultValue={e.worked ?? ""} placeholder="Креатив №3 с UGC, время 18–22" /></label>
      <label className="label"><span>Что не сработало</span><textarea className="input" name="failed" defaultValue={e.failed ?? ""} /></label>
      <label className="label"><span>План на завтра</span><textarea className="input" name="plan" defaultValue={e.plan ?? ""} /></label>
      <div><Submit>Сохранить</Submit></div>
    </form>
  );
}
