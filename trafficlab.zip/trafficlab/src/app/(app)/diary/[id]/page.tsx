import Link from "next/link";
import { notFound } from "next/navigation";
import { getMe } from "@/lib/auth";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { dateShort, today } from "@/lib/format";
import { DiaryForm } from "../DiaryForm";
import { commentEntry, deleteEntry, saveEntry } from "../actions";

export default async function Entry({ params, searchParams }: { params: { id: string }; searchParams: { error?: string } }) {
  const { supabase, user, isStaff } = await getMe();
  const { data: e } = await supabase.from("diary_entries").select("*, profiles!diary_entries_user_id_fkey(full_name)").eq("id", params.id).single();
  if (!e) notFound();
  const own = e.user_id === user.id;
  const { data: offers } = await supabase.from("offers").select("id, name, geo").order("name");
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/diary">← Дневник</Link>
      <PageHead title={`Запись за ${dateShort(e.entry_date)}`} sub={(e as any).profiles?.full_name} />
      <div className="flex flex-col gap-4">
        <ErrorNote error={searchParams.error} />
        {e.curator_comment && <div className="max-w-2xl whitespace-pre-wrap rounded-card bg-accent-soft p-4"><b>Комментарий куратора</b>{"\n"}{e.curator_comment}</div>}
        {own ? (
          <>
            <DiaryForm action={saveEntry} offers={offers ?? []} entry={e} today={today()} />
            <form action={deleteEntry}><input type="hidden" name="id" value={e.id} /><Submit className="btn-bad">Удалить запись</Submit></form>
          </>
        ) : (
          <div className="card max-w-2xl whitespace-pre-wrap">
            <p><b>Что сработало:</b> {e.worked ?? "—"}</p><p><b>Что не сработало:</b> {e.failed ?? "—"}</p><p><b>План:</b> {e.plan ?? "—"}</p>
          </div>
        )}
        {isStaff && !own && (
          <form action={commentEntry} className="card flex max-w-2xl flex-col gap-3">
            <input type="hidden" name="id" value={e.id} />
            <Field label="Комментарий куратора"><textarea className="input min-h-[100px]" name="curator_comment" defaultValue={e.curator_comment ?? ""} /></Field>
            <div><Submit>Сохранить комментарий</Submit></div>
          </form>
        )}
      </div>
    </>
  );
}
