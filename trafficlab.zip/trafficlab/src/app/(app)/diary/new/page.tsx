import Link from "next/link";
import { getMe } from "@/lib/auth";
import { ErrorNote, PageHead } from "@/components/ui";
import { today } from "@/lib/format";
import { DiaryForm } from "../DiaryForm";
import { saveEntry } from "../actions";

export default async function NewEntry({ searchParams }: { searchParams: { error?: string } }) {
  const { supabase } = await getMe();
  const { data: offers } = await supabase.from("offers").select("id, name, geo").order("name");
  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/diary">← Дневник</Link>
      <PageHead title="Записать день" sub="Расход, доход, клики и лиды — ROI, CPL, CR и EPC посчитаются сами. +10 XP за запись." />
      <ErrorNote error={searchParams.error} />
      <DiaryForm action={saveEntry} offers={offers ?? []} today={today()} />
    </>
  );
}
