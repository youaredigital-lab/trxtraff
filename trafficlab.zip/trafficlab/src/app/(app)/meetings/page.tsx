import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Chips, Empty, PageHead } from "@/components/ui";
import { dateShort } from "@/lib/format";
import { MEETING_KIND } from "@/lib/constants";

const KIND = MEETING_KIND;

export default async function Meetings({ searchParams }: { searchParams: { kind?: string; q?: string } }) {
  const { supabase, user, isAdmin } = await getMe();
  const kind = searchParams.kind ?? "all";
  let q = supabase.from("meetings").select("id, title, description, kind, recorded_at, duration_min, tags, visibility").order("recorded_at", { ascending: false });
  if (kind !== "all") q = q.eq("kind", kind);
  if (searchParams.q) q = q.ilike("title", `%${searchParams.q}%`);
  const [{ data }, { data: views }] = await Promise.all([q, supabase.from("meeting_views").select("meeting_id").eq("user_id", user.id)]);
  const seen = new Set((views ?? []).map((v) => v.meeting_id));

  return (
    <>
      <PageHead title="Записи митов" sub="Планёрки, вебинары и разборы кейсов команды. Пропустили мит — посмотрите запись.">
        {isAdmin && <Link className="btn-pri" href="/admin/meetings/new">Загрузить запись</Link>}
      </PageHead>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Chips current={kind} hrefFor={(k) => `/meetings?kind=${k}`} items={[["all", "Все"], ...Object.entries(KIND)] as [string, string][]} />
        <form action="/meetings" className="flex gap-2"><input type="hidden" name="kind" value={kind} /><input className="input w-56" name="q" defaultValue={searchParams.q} placeholder="Поиск по названию" /><button className="btn">Найти</button></form>
      </div>
      {!data?.length ? <Empty title="Записей пока нет">{isAdmin ? "Загрузите первую запись мита или вставьте ссылку на видео." : "Администратор добавит записи после митов."}</Empty> : (
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fill,minmax(280px,1fr))]">
          {data.map((m) => (
            <Link key={m.id} href={`/meetings/${m.id}`} className="card flex flex-col gap-2 transition hover:border-muted">
              <div className="grid aspect-video place-items-center rounded-lg bg-sunk">
                <span className="grid h-12 w-12 place-items-center rounded-full bg-accent text-accent-ink">▶</span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="pill">{KIND[m.kind]}</span>
                {m.visibility !== "all" && <span className="pill-wait">{m.visibility === "staff" ? "только команда" : "TL2+"}</span>}
                {seen.has(m.id) ? <span className="pill-ok">просмотрено</span> : <span className="pill-info">новое</span>}
              </div>
              <b className="leading-snug">{m.title}</b>
              <span className="text-[13px] text-muted">{dateShort(m.recorded_at)}{m.duration_min ? ` · ${m.duration_min} мин` : ""}{m.tags?.length ? ` · ${m.tags.join(", ")}` : ""}</span>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
