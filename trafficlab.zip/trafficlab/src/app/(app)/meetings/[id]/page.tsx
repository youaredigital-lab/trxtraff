import Link from "next/link";
import { notFound } from "next/navigation";
import { getMe } from "@/lib/auth";
import { PageHead, Prose } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { VideoPlayer } from "@/components/VideoPlayer";
import { signedMedia } from "@/lib/media";
import { markViewed } from "../actions";
import { MEETING_KIND as KIND } from "@/lib/constants";

export default async function Meeting({ params }: { params: { id: string } }) {
  const { supabase, user, isAdmin } = await getMe();
  const { data: m } = await supabase.from("meetings").select("*, tracks(title)").eq("id", params.id).single();
  if (!m) notFound();
  const [src, { data: view }, viewsRes] = await Promise.all([
    signedMedia(supabase, m.video_path),
    supabase.from("meeting_views").select("viewed_at").eq("user_id", user.id).eq("meeting_id", m.id).maybeSingle(),
    isAdmin ? supabase.from("meeting_views").select("user_id", { count: "exact", head: true }).eq("meeting_id", m.id) : Promise.resolve({ count: null }),
  ]);

  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/meetings">← Все записи</Link>
      <PageHead title={m.title} sub={`${KIND[m.kind]} · ${new Date(m.recorded_at).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" })}${m.duration_min ? ` · ${m.duration_min} мин` : ""}`}>
        {isAdmin && <span className="pill">Посмотрели: {viewsRes.count ?? 0}</span>}
        {isAdmin && <Link className="btn" href={`/admin/meetings/${m.id}`}>Редактировать</Link>}
      </PageHead>
      <div className="flex max-w-4xl flex-col gap-4">
        <VideoPlayer src={src} url={m.video_url} title={m.title} />
        <div className="flex flex-wrap items-center gap-2">
          {(m as any).tracks?.title && <span className="pill">Трек: {(m as any).tracks.title}</span>}
          {m.tags?.map((t: string) => <span key={t} className="pill">{t}</span>)}
          {view ? <span className="pill-ok">Просмотрено</span> : (
            <form action={markViewed}><input type="hidden" name="id" value={m.id} /><Submit className="btn btn-sm">Отметить просмотренным</Submit></form>
          )}
        </div>
        {m.description && <div className="card"><Prose text={m.description} /></div>}
      </div>
    </>
  );
}
