"use server";
import { revalidatePath } from "next/cache";
import { getMe } from "@/lib/auth";

export async function markViewed(fd: FormData) {
  const { supabase } = await getMe();
  await supabase.from("meeting_views").upsert({ meeting_id: String(fd.get("id")) }, { onConflict: "user_id,meeting_id", ignoreDuplicates: true });
  revalidatePath("/meetings");
}
