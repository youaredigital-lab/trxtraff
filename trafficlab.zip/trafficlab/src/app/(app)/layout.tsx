import { getMe } from "@/lib/auth";
import { Nav } from "@/components/Nav";
import { ROLES, TRUST_LEVELS } from "@/lib/constants";
import { signOut } from "../login/actions";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const me = await getMe();
  const { supabase, isStaff, isAdmin, user } = me;

  const counts = await Promise.all(
    isStaff
      ? [
          supabase.from("homework").select("id", { count: "exact", head: true }).eq("status", "submitted"),
          supabase.from("tickets").select("id", { count: "exact", head: true }).in("status", ["open", "progress"]),
          supabase.from("offer_tests").select("id", { count: "exact", head: true }).eq("status", "idea"),
          supabase.from("offer_proposals").select("id", { count: "exact", head: true }).eq("status", "pending"),
        ]
      : [
          supabase.from("homework").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "returned"),
          supabase.from("tickets").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "waiting"),
        ]
  );
  const [hw, tk, tests, props] = counts.map((c) => c.count ?? 0);

  const items = [
    { href: "/", label: "Обзор" },
    { href: "/learn", label: "Обучение" },
    { href: "/meetings", label: "Записи митов" },
    { href: "/homework", label: "Домашние задания", count: hw, hot: true },
    { href: "/offers", label: "Офферы", count: isAdmin ? props : 0 },
    { href: "/tests", label: "Тесты офферов", count: isStaff ? tests : 0 },
    { href: "/diary", label: "Дневник" },
    { href: "/requests", label: "Заявки" },
    { href: "/tickets", label: "Тикеты", count: tk, hot: true },
    ...(isAdmin ? [{ href: "/admin", label: "Админка" }] : []),
    { href: "/settings", label: "Профиль" },
  ];
  const tl = me.stats.trust_level ?? 0;

  return (
    <div className="grid min-h-screen md:grid-cols-[236px_minmax(0,1fr)]">
      <aside className="flex flex-col gap-4 border-b border-line bg-panel px-4 py-4 md:sticky md:top-0 md:h-screen md:border-b-0 md:border-r md:py-5">
        <div className="flex items-center gap-2 font-display text-[17px] font-bold">
          <span className="grid h-[22px] w-[22px] place-items-center rounded-md bg-accent text-[11px] text-accent-ink">TL</span>
          TrafficLab
        </div>
        <Nav items={items} />
        <div className="flex flex-wrap items-center justify-between gap-2 text-[13px] md:mt-auto md:flex-col md:items-stretch">
          <div>
            <div className="font-semibold">{me.profile.full_name}</div>
            <div className="text-muted">
              {isStaff ? ROLES[me.profile.role] : `TL${tl} · ${TRUST_LEVELS[tl].name} · ${me.stats.xp} XP`}
            </div>
          </div>
          <form action={signOut}><button className="btn-ghost btn-sm px-0">Выйти</button></form>
        </div>
      </aside>
      <main className="min-w-0 max-w-[1180px] px-4 pb-16 pt-6 md:px-7">{children}</main>
    </div>
  );
}
