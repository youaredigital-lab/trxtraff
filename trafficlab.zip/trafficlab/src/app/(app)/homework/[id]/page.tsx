import Link from "next/link";
import { notFound } from "next/navigation";
import { getMe } from "@/lib/auth";
import { aiEnabled } from "@/lib/ai";
import { ErrorNote, Field, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { AiButton } from "@/components/AiButton";
import { aiReview, reviewHomework } from "../actions";
import { ago } from "@/lib/format";

export default async function HomeworkItem({ params, searchParams }: { params: { id: string }; searchParams: { error?: string } }) {
  const { supabase, isStaff, user } = await getMe();
  const { data: h } = await supabase.from("homework").select("*, lessons(id, title, hw_prompt, hw_rubric), profiles!homework_user_id_fkey(full_name)").eq("id", params.id).single();
  if (!h) notFound();
  const l: any = h.lessons;
  const rubric: string[] = l?.hw_rubric ?? [];
  const reviewing = isStaff && h.status === "submitted";

  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href="/homework">← Все ДЗ</Link>
      <PageHead title={l?.title ?? "ДЗ"} sub={`${(h as any).profiles?.full_name} · сдано ${ago(h.created_at)}`} />
      <div className="flex max-w-3xl flex-col gap-4">
        <ErrorNote error={searchParams.error} />
        <div className="card flex flex-col gap-3">
          <p className="hint">{l?.hw_prompt}</p>
          <div className="whitespace-pre-wrap">{h.answer}</div>
          {h.link && <a className="text-accent underline" href={h.link} target="_blank" rel="noopener noreferrer">{h.link}</a>}
        </div>
        {h.ai_review && <div className="whitespace-pre-wrap rounded-card bg-accent-soft p-4"><b>ИИ-предпроверка ученика</b>{"\n"}{h.ai_review}</div>}
        {reviewing ? (
          <form id="review" action={reviewHomework} className="card flex flex-col gap-3">
            <input type="hidden" name="id" value={h.id} /><input type="hidden" name="rubric_count" value={rubric.length} />
            <h2 className="font-display text-base font-medium">Оценка по рубрике</h2>
            <p className="hint">0 — нет, 1 — частично, 2 — полностью</p>
            {rubric.map((r, i) => (
              <div key={i} className="flex items-center justify-between gap-3 border-b border-line py-1.5">
                <span>{r}</span>
                <select className="input w-20" name={`r_${i}`} defaultValue="2"><option>0</option><option>1</option><option>2</option></select>
              </div>
            ))}
            <Field label="Комментарий ученику"><textarea className="input min-h-[110px]" name="comment" placeholder="Что хорошо, что исправить, ссылка на урок" /></Field>
            {aiEnabled() && <AiButton action={aiReview} label="ИИ: оценка и черновик комментария" formId="review" />}
            <div className="flex flex-wrap gap-2">
              <Submit className="btn-good" name="status" value="accepted">Принять</Submit>
              <Submit className="btn-bad" name="status" value="returned">На доработку</Submit>
            </div>
          </form>
        ) : (
          <div className="card flex flex-col gap-2">
            <div>{{ submitted: <span className="pill-wait">На проверке</span>, accepted: <span className="pill-ok">Принято</span>, returned: <span className="pill-bad">На доработку</span> }[h.status as string]}</div>
            {h.scores && rubric.map((r, i) => (
              <div key={i} className="flex justify-between border-b border-line py-1.5"><span>{r}</span><b className="font-mono">{h.scores[i] ?? "—"}/2</b></div>
            ))}
            {h.comment && <div className="whitespace-pre-wrap rounded-lg border border-line p-3"><div className="text-xs text-muted">Комментарий куратора</div>{h.comment}</div>}
            {h.user_id === user.id && h.status === "returned" && <div><Link className="btn-pri" href={`/learn/${l.id}`}>Сдать заново</Link></div>}
          </div>
        )}
      </div>
    </>
  );
}
