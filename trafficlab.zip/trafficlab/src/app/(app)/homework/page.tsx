import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Chips, Empty, PageHead, Table } from "@/components/ui";
import { ago, dur } from "@/lib/format";

const PILL: Record<string, JSX.Element> = {
  submitted: <span className="pill-wait">На проверке</span>,
  accepted: <span className="pill-ok">Принято</span>,
  returned: <span className="pill-bad">На доработку</span>,
};

export default async function Homework({ searchParams }: { searchParams: { status?: string } }) {
  const { supabase, user, isStaff } = await getMe();
  const status = searchParams.status ?? (isStaff ? "submitted" : "all");
  let q = supabase.from("homework").select("id, status, created_at, scores, user_id, lessons(title, hw_rubric), profiles!homework_user_id_fkey(full_name)");
  if (!isStaff) q = q.eq("user_id", user.id);
  if (status !== "all") q = q.eq("status", status);
  const { data } = await q.order("created_at", { ascending: isStaff });

  return (
    <>
      <PageHead title="Домашние задания" sub={isStaff ? "Очередь проверки. Цель — проверка в течение 48 часов." : "Ваши сданные задания и отзывы куратора."} />
      <div className="mb-3.5">
        <Chips current={status} hrefFor={(k) => `/homework?status=${k}`} items={[["submitted", "На проверке"], ["returned", "На доработке"], ["accepted", "Принято"], ["all", "Все"]]} />
      </div>
      {!data?.length ? (
        <Empty title={isStaff ? "Очередь пуста" : "Здесь появятся ваши ДЗ"}>{isStaff ? "Работ в этом статусе нет." : "Сдайте задание на странице урока — оно попадёт к куратору."}</Empty>
      ) : (
        <Table>
          <thead><tr>{isStaff && <th>Ученик</th>}<th>Урок</th><th>Статус</th><th>Сдано</th><th>{isStaff ? "SLA 48 ч" : "Баллы"}</th><th></th></tr></thead>
          <tbody>
            {data.map((h: any) => {
              const left = 48 * 36e5 - (Date.now() - Date.parse(h.created_at));
              return (
                <tr key={h.id}>
                  {isStaff && <td>{h.profiles?.full_name}</td>}
                  <td>{h.lessons?.title}</td>
                  <td>{PILL[h.status]}</td>
                  <td>{ago(h.created_at)}</td>
                  <td className={isStaff ? "" : "num"}>
                    {isStaff
                      ? h.status !== "submitted" ? "—" : left < 0 ? <span className="pill-bad">просрочено {dur(left)}</span> : <span className="pill">{dur(left)}</span>
                      : h.scores ? `${h.scores.reduce((a: number, b: number) => a + b, 0)}/${h.scores.length * 2}` : "—"}
                  </td>
                  <td><Link className="btn btn-sm" href={`/homework/${h.id}`}>{isStaff && h.status === "submitted" ? "Проверить" : "Открыть"}</Link></td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      )}
    </>
  );
}
