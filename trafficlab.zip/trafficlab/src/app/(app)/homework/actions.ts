"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { askClaude, aiEnabled } from "@/lib/ai";
import { notifyUser } from "@/lib/telegram";

export async function reviewHomework(fd: FormData) {
  const { supabase, isStaff } = await getMe();
  if (!isStaff) redirect("/homework");
  const id = String(fd.get("id"));
  const status = String(fd.get("status"));
  const n = Number(fd.get("rubric_count") ?? 0);
  const scores = Array.from({ length: n }, (_, i) => Number(fd.get(`r_${i}`) ?? 0));
  const { data, error } = await supabase
    .from("homework")
    .update({ status, scores, comment: String(fd.get("comment") ?? "").trim() || null })
    .eq("id", id)
    .select("user_id, lessons(title)")
    .single();
  if (error) redirect(`/homework/${id}?error=${encodeURIComponent(error.message)}`);
  await notifyUser(
    data.user_id,
    status === "accepted" ? `ДЗ «${(data as any).lessons?.title}» принято. +100 XP` : `ДЗ «${(data as any).lessons?.title}» вернули на доработку`,
    `/homework/${id}`
  );
  revalidatePath("/homework");
  redirect("/homework");
}

export async function aiReview(fd: FormData) {
  if (!aiEnabled()) return { error: "ИИ-функции не настроены: добавьте ANTHROPIC_API_KEY." };
  const { supabase } = await getMe();
  const { data: h } = await supabase.from("homework").select("answer, lessons(hw_prompt, hw_rubric)").eq("id", String(fd.get("id"))).single();
  const l: any = (h as any)?.lessons;
  try {
    const text = await askClaude(
      `Ты старший куратор школы арбитража трафика. Оцени домашнее задание по критериям: для каждого критерия 0/1/2 и одна фраза почему; затем черновик комментария ученику (3–5 предложений, дружелюбно, конкретно). На русском, без вступлений.\n\nЗадание: ${l?.hw_prompt}\nКритерии:\n- ${(l?.hw_rubric ?? []).join("\n- ")}\n\nОтвет ученика:\n${(h?.answer ?? "").slice(0, 6000)}`
    );
    return { text: text ?? "" };
  } catch {
    return { error: "ИИ сейчас не ответил, попробуйте ещё раз." };
  }
}
