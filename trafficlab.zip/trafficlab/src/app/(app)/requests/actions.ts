"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getMe } from "@/lib/auth";
import { STAFF, TICKET_TYPES } from "@/lib/constants";
import { daysAgo, money, pct, sumMetrics } from "@/lib/format";
import { notifyStaff } from "@/lib/telegram";

const s = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

export async function createRequest(fd: FormData) {
  const { supabase, user, profile } = await getMe();
  const type = s(fd, "type");
  const testId = s(fd, "test_id") || null;
  let title = "";
  let fields: Record<string, string> = {};
  let priority = s(fd, "priority") || "normal";
  let body = "";

  if (type === "accounts") {
    fields = { platform: s(fd, "platform"), kind: s(fd, "kind"), geo: s(fd, "geo").toUpperCase(), qty: s(fd, "qty"), limit: s(fd, "limit"), brief: s(fd, "note") };
    title = `${fields.qty} × ${fields.kind} · ${fields.platform} ${fields.geo}`;
  } else if (type === "cards") {
    fields = {
      platform: s(fd, "platform"), card_type: s(fd, "card_type"), currency: s(fd, "currency"), qty: s(fd, "qty"),
      limit: s(fd, "limit"), topup: s(fd, "topup"), bin: s(fd, "bin"), brief: s(fd, "note"),
    };
    title = `${fields.qty} × ${fields.card_type} ${fields.currency} · ${fields.platform}`;
  } else if (type === "creatives") {
    fields = { offer: s(fd, "offer"), format: s(fd, "format"), lang: s(fd, "lang"), qty: s(fd, "qty"), deadline: s(fd, "deadline"), brief: s(fd, "brief"), refs: s(fd, "refs") };
    title = `${fields.qty} × ${fields.format}${fields.offer ? ` · ${fields.offer}` : ""}`;
  } else if (type === "appeal") {
    fields = { category: s(fd, "category") };
    title = s(fd, "title");
    body = s(fd, "text");
    priority = "low";
  } else if (type === "call") {
    if (!s(fd, "slot")) redirect(`/requests/new?type=call&error=${encodeURIComponent("Выберите время")}`);
    fields = { staff: s(fd, "staff"), day: s(fd, "day"), slot: s(fd, "slot"), duration: s(fd, "duration") };
    if (fd.get("attach_diary") === "on") {
      const { data } = await supabase.from("diary_entries").select("spend, revenue, clicks, leads").eq("user_id", user.id).gte("entry_date", daysAgo(14));
      const m = sumMetrics(data ?? []);
      fields.diary = `14 дней: расход ${money(m.spend)}, профит ${money(m.profit)}, ROI ${pct(m.roi)}`;
    }
    title = `${s(fd, "title") || "Созвон"} · ${STAFF[fields.staff]}, ${fields.day} ${fields.slot}`;
  } else {
    redirect("/requests");
  }

  const { data, error } = await supabase
    .from("tickets")
    .insert({ type, title, priority, fields, test_id: testId, anonymous: type === "appeal" && fd.get("anonymous") === "on", category: fields.category ?? null })
    .select("id")
    .single();
  if (error) {
    const msg = error.code === "23505" ? "Этот слот уже заняли — выберите другое время" : error.message;
    redirect(`/requests/new?type=${type}&error=${encodeURIComponent(msg)}`);
  }
  if (body) await supabase.from("ticket_messages").insert({ ticket_id: data.id, body });
  await notifyStaff(`Новая заявка «${TICKET_TYPES[type]}» от ${type === "appeal" && fd.get("anonymous") === "on" ? "анонима" : profile.full_name}: ${title}`, `/tickets/${data.id}`);
  revalidatePath("/requests");
  redirect(`/requests?type=${type}&sent=1`);
}
