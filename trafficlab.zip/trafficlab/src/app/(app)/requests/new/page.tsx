import Link from "next/link";
import { getMe } from "@/lib/auth";
import { ErrorNote, Field, Lock, PageHead } from "@/components/ui";
import { Submit } from "@/components/Submit";
import { REQUESTS, TRUST_LEVELS } from "@/lib/constants";
import { createRequest } from "../actions";
import { CallSlots } from "../CallSlots";

const sel = (name: string, opts: string[], def?: string) => (
  <select className="input" name={name} defaultValue={def}>{opts.map((o) => <option key={o}>{o}</option>)}</select>
);

export default async function NewRequest({ searchParams }: { searchParams: { type?: string; test?: string; error?: string } }) {
  const { supabase, user, isStaff, stats } = await getMe();
  const type = REQUESTS[searchParams.type ?? ""] ? searchParams.type! : "accounts";
  const r = REQUESTS[type];
  const tl = isStaff ? 4 : stats.trust_level;
  const [{ data: tests }, { data: offers }] = await Promise.all([
    supabase.from("offer_tests").select("id, source, geo, offers(name)").eq("user_id", user.id).in("status", ["approved", "running"]),
    supabase.from("offers").select("id, name").order("name"),
  ]);
  const test: any = (tests ?? []).find((t) => t.id === searchParams.test);
  const days: [string, string][] = [];
  for (let i = 1; days.length < 7; i++) {
    const d = new Date(Date.now() + i * 864e5);
    if (d.getDay() % 6) days.push([d.toISOString().slice(0, 10), d.toLocaleDateString("ru-RU", { weekday: "short", day: "numeric", month: "short" })]);
  }

  const testSelect = (
    <Field label="Под какой тест" hint="Заявки под тест одобряются быстрее.">
      <select className="input" name="test_id" defaultValue={searchParams.test ?? ""}>
        <option value="">— без теста —</option>
        {(tests ?? []).map((t: any) => <option key={t.id} value={t.id}>{t.offers?.name} · {t.source} · {t.geo}</option>)}
      </select>
    </Field>
  );
  const prio = (
    <Field label="Срочность">
      <select className="input" name="priority" defaultValue="normal">
        <option value="normal">В течение дня</option><option value="high">В течение 2 часов</option><option value="low">Не срочно</option>
      </select>
    </Field>
  );

  return (
    <>
      <Link className="btn-ghost btn-sm mb-3" href={`/requests?type=${type}`}>← Заявки</Link>
      <PageHead title={`Заявка: ${r.title.toLowerCase()}`} sub={r.desc} />
      {tl < r.tl ? <Lock level={r.tl} need={TRUST_LEVELS[r.tl].need} /> : (
        <form action={createRequest} className="card flex max-w-2xl flex-col gap-3.5">
          <input type="hidden" name="type" value={type} />
          <ErrorNote error={searchParams.error} />
          {type === "accounts" && <>
            {testSelect}
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Платформа">{sel("platform", ["Facebook", "Google", "TikTok"], test?.source)}</Field>
              <Field label="Тип">{sel("kind", ["Автореги", "Фарм 7+ дней", "Бизнес-менеджер", "Кинг + БМ", "Агентский"])}</Field>
              <Field label="ГЕО аккаунтов"><input className="input" name="geo" defaultValue={test?.geo} placeholder="US" required /></Field>
              <Field label="Количество"><input className="input" name="qty" type="number" min="1" defaultValue="5" required /></Field>
              <Field label="Дневной лимит, $"><input className="input" name="limit" type="number" min="0" defaultValue="50" /></Field>
              {prio}
            </div>
            <Field label="Комментарий"><textarea className="input" name="note" placeholder="Прокси, антидетект, особые требования" /></Field>
          </>}
          {type === "cards" && <>
            {testSelect}
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Для какой платформы">{sel("platform", ["Facebook", "Google", "TikTok", "Другое"], test?.source)}</Field>
              <Field label="Тип карты">{sel("card_type", ["Виртуальная", "Виртуальная с 3DS", "Предоплаченная"])}</Field>
              <Field label="Валюта">{sel("currency", ["USD", "EUR", "GBP"])}</Field>
              <Field label="Количество карт"><input className="input" name="qty" type="number" min="1" defaultValue="3" required /></Field>
              <Field label="Лимит на карту, $"><input className="input" name="limit" type="number" min="0" defaultValue="500" /></Field>
              <Field label="Первичное пополнение, $"><input className="input" name="topup" type="number" min="0" defaultValue="200" /></Field>
              <Field label="Предпочтительный BIN / банк" hint="Если знаете, какой проходит в этой сети."><input className="input" name="bin" placeholder="необязательно" /></Field>
              {prio}
            </div>
            <Field label="Комментарий"><textarea className="input" name="note" placeholder="Под какие аккаунты, нужна ли отдельная карта на каждый" /></Field>
          </>}
          {type === "creatives" && <>
            {testSelect}
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Оффер">{sel("offer", (offers ?? []).map((o) => o.name), test?.offers?.name)}</Field>
              <Field label="Формат">{sel("format", ["Видео 9:16", "Видео 1:1", "Статика", "UGC", "Плейбл"])}</Field>
              <Field label="Язык"><input className="input" name="lang" placeholder="польский" required /></Field>
              <Field label="Количество"><input className="input" name="qty" type="number" min="1" defaultValue="4" required /></Field>
              <Field label="Дедлайн"><input className="input" name="deadline" type="date" /></Field>
              {prio}
            </div>
            <Field label="ТЗ" hint="Шаблон: хук → проблема → решение → доказательство → CTA."><textarea className="input min-h-[120px]" name="brief" required /></Field>
            <Field label="Референсы (ссылки)"><input className="input" name="refs" placeholder="https://" /></Field>
          </>}
          {type === "appeal" && <>
            <Field label="Тема"><input className="input" name="title" required placeholder="Идея: общий пул прокси" /></Field>
            <Field label="Тип">{sel("category", ["Идея", "Жалоба", "Вопрос к руководству", "Благодарность"])}</Field>
            <Field label="Текст"><textarea className="input min-h-[120px]" name="text" required /></Field>
            <label className="flex items-center gap-2"><input type="checkbox" name="anonymous" /> Отправить анонимно</label>
          </>}
          {type === "call" && <>
            <Field label="Тема"><input className="input" name="title" placeholder="Разбор дневника за неделю" /></Field>
            <CallSlots days={days} />
            <Field label="Длительность">{sel("duration", ["30", "15", "60"])}</Field>
            <label className="flex items-center gap-2"><input type="checkbox" name="attach_diary" defaultChecked /> Приложить сводку дневника за 14 дней</label>
          </>}
          <div><Submit>Отправить заявку</Submit></div>
        </form>
      )}
    </>
  );
}
