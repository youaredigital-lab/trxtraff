import Link from "next/link";
import { getMe } from "@/lib/auth";
import { Empty, Lock, PageHead, Table } from "@/components/ui";
import { REQUESTS, TICKET_STATUS, TRUST_LEVELS } from "@/lib/constants";
import { ago } from "@/lib/format";

export default async function Requests({ searchParams }: { searchParams: { type?: string; sent?: string } }) {
  const { supabase, user, isStaff, stats } = await getMe();
  const type = REQUESTS[searchParams.type ?? ""] ? searchParams.type! : "accounts";
  const r = REQUESTS[type];
  const tl = isStaff ? 4 : stats.trust_level;
  const locked = tl < r.tl;
  let q = supabase.from("tickets").select("id, title, status, created_at, anonymous, profiles!tickets_user_id_fkey(full_name)").eq("type", type).order("created_at", { ascending: false });
  if (!isStaff) q = q.eq("user_id", user.id);
  const { data } = await q;

  return (
    <>
      <PageHead title="Заявки" sub="Аккаунты, карты, креативы, обращения и созвоны — с понятным статусом вместо переписки в личке." />
      <div className="mb-4 flex gap-1 overflow-x-auto border-b border-line">
        {Object.entries(REQUESTS).map(([k, v]) => (
          <Link key={k} href={`/requests?type=${k}`} className={`-mb-px whitespace-nowrap border-b-2 px-3 py-2 font-medium ${k === type ? "border-accent text-ink" : "border-transparent text-muted"}`}>{v.title}</Link>
        ))}
      </div>
      <div className="flex flex-col gap-4">
        {searchParams.sent && <div className="rounded-card bg-pos-soft px-4 py-3 text-pos">Заявка отправлена. Статус обновится здесь, уведомление придёт в Telegram.</div>}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="max-w-[62ch] text-muted">{r.desc}</p>
          {!locked && <Link className="btn-pri" href={`/requests/new?type=${type}`}>Новая заявка</Link>}
        </div>
        {locked && <Lock level={r.tl} need={TRUST_LEVELS[r.tl].need}><Link className="btn btn-sm" href="/learn">К урокам</Link></Lock>}
        {!data?.length ? <Empty title="Заявок пока нет">{locked ? "" : "Создайте первую — статус будет виден здесь."}</Empty> : (
          <Table>
            <thead><tr>{isStaff && <th>Автор</th>}<th>Заявка</th><th>Статус</th><th>Создана</th></tr></thead>
            <tbody>
              {data.map((t: any) => (
                <tr key={t.id}>
                  {isStaff && <td>{t.anonymous ? <span className="text-muted">анонимно</span> : t.profiles?.full_name}</td>}
                  <td><Link className="text-accent" href={`/tickets/${t.id}`}>{t.title}</Link></td>
                  <td><span className="pill">{TICKET_STATUS[t.status]}</span></td>
                  <td>{ago(t.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </div>
    </>
  );
}
