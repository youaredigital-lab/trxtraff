"use client";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { CALL_SLOTS, STAFF } from "@/lib/constants";

export function CallSlots({ days }: { days: [string, string][] }) {
  const [staff, setStaff] = useState("curator");
  const [day, setDay] = useState(days[0][0]);
  const [slot, setSlot] = useState("");
  const [taken, setTaken] = useState<string[]>([]);
  useEffect(() => {
    const supabase = createClient();
    supabase.rpc("taken_call_slots", { p_staff: staff, p_day: day }).then(({ data }) => setTaken((data as string[]) ?? []));
    setSlot("");
  }, [staff, day]);
  return (
    <>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="label"><span>С кем</span>
          <select className="input" name="staff" value={staff} onChange={(e) => setStaff(e.target.value)}>
            {Object.entries(STAFF).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </label>
        <label className="label"><span>День</span>
          <select className="input" name="day" value={day} onChange={(e) => setDay(e.target.value)}>
            {days.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </label>
      </div>
      <div className="label">
        <span>Время (Киев)</span>
        <div className="flex flex-wrap gap-1.5">
          {CALL_SLOTS.map((s) => {
            const busy = taken.includes(s);
            return (
              <button key={s} type="button" disabled={busy} onClick={() => setSlot(s)}
                className={`${slot === s ? "chip-on" : "chip"} ${busy ? "cursor-not-allowed line-through opacity-40" : ""}`}>{s}</button>
            );
          })}
        </div>
        <input type="hidden" name="slot" value={slot} />
      </div>
    </>
  );
}
