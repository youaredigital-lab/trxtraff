"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function signIn(fd: FormData) {
  const supabase = createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: String(fd.get("email")).trim(),
    password: String(fd.get("password")),
  });
  if (error) redirect(`/login?error=${encodeURIComponent("Неверная почта или пароль")}`);
  redirect(String(fd.get("next") || "/"));
}

export async function signUp(fd: FormData) {
  const supabase = createClient();
  const email = String(fd.get("email")).trim();
  const { data, error } = await supabase.auth.signUp({
    email,
    password: String(fd.get("password")),
    options: {
      data: { full_name: String(fd.get("full_name") || "").trim() },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/auth/callback`,
    },
  });
  if (error) redirect(`/login?mode=signup&error=${encodeURIComponent(error.message)}`);
  if (!data.session) redirect(`/login?info=${encodeURIComponent("Проверьте почту и подтвердите регистрацию")}`);
  redirect("/");
}

export async function signOut() {
  const supabase = createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
