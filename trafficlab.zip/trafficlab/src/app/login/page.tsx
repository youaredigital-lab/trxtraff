import { signIn, signUp } from "./actions";
import { Submit } from "@/components/Submit";

export default function Login({ searchParams }: { searchParams: { mode?: string; error?: string; info?: string; next?: string } }) {
  const signup = searchParams.mode === "signup";
  return (
    <main className="grid min-h-screen place-items-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex items-center gap-2 font-display text-lg font-bold">
          <span className="grid h-7 w-7 place-items-center rounded-md bg-accent text-xs text-accent-ink">TL</span>TrafficLab
        </div>
        <div className="card flex flex-col gap-4 p-6">
          <div>
            <h1 className="font-display text-xl font-semibold">{signup ? "Регистрация" : "Вход"}</h1>
            <p className="mt-1 text-muted">{signup ? "Создайте аккаунт ученика. Роль назначит администратор." : "Обучение, офферы, дневник и заявки команды."}</p>
          </div>
          {searchParams.error && <div className="rounded-lg bg-neg-soft px-3 py-2 text-neg">{searchParams.error}</div>}
          {searchParams.info && <div className="rounded-lg bg-pos-soft px-3 py-2 text-pos">{searchParams.info}</div>}
          <form action={signup ? signUp : signIn} className="flex flex-col gap-3">
            <input type="hidden" name="next" value={searchParams.next ?? "/"} />
            {signup && (
              <label className="label"><span>Имя</span><input className="input" name="full_name" required autoComplete="name" /></label>
            )}
            <label className="label"><span>Почта</span><input className="input" name="email" type="email" required autoComplete="email" /></label>
            <label className="label"><span>Пароль</span><input className="input" name="password" type="password" minLength={8} required autoComplete={signup ? "new-password" : "current-password"} /></label>
            <Submit>{signup ? "Создать аккаунт" : "Войти"}</Submit>
          </form>
          <a className="text-center text-[13px] text-accent" href={signup ? "/login" : "/login?mode=signup"}>
            {signup ? "Уже есть аккаунт? Войти" : "Нет аккаунта? Зарегистрироваться"}
          </a>
        </div>
      </div>
    </main>
  );
}
