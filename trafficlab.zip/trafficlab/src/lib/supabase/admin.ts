import { createClient } from "@supabase/supabase-js";

/** Сервисный клиент: обходит RLS. Только для серверных задач (бот, крон, уведомления). */
export function createAdminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) return null;
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
