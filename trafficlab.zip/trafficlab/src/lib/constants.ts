export const TRUST_LEVELS = [
  { n: 0, name: "Новичок", need: "Старт", gives: "Уроки, квизы, тикеты, предложения офферов" },
  { n: 1, name: "Стажёр", need: "3 урока пройдено", gives: "Заказ креативов" },
  { n: 2, name: "Байер", need: "6 уроков и 1 принятое ДЗ", gives: "Аккаунты, карты, тесты офферов" },
  { n: 3, name: "Профи", need: "1 тест оффера в плюс", gives: "Приоритетные заявки, созвон с тимлидом" },
  { n: 4, name: "Лид", need: "Профит $1 000 за 30 дней", gives: "Приватные офферы, наставничество" },
];

export const ROLES: Record<string, string> = {
  student: "Ученик", buyer: "Медиабайер", curator: "Куратор", teamlead: "Тимлид", admin: "Администратор",
};

export const SOURCES = ["Facebook", "Google", "TikTok", "Push", "Native", "SEO"];

export const TEST_STATUS: [string, string][] = [
  ["idea", "Идея"], ["approved", "Одобрен"], ["running", "В работе"],
  ["plus", "Плюс"], ["minus", "Минус"], ["stopped", "Стоп"],
];
export const TEST_LABEL = Object.fromEntries(TEST_STATUS);

export const TICKET_TYPES: Record<string, string> = {
  ticket: "Тикет", accounts: "Аккаунты", cards: "Карты", creatives: "Креативы", appeal: "Обращение", call: "Созвон",
};
export const TICKET_STATUS: Record<string, string> = {
  open: "Новый", progress: "В работе", waiting: "Ждём ответа", done: "Решён", rejected: "Отклонён",
};
export const PRIORITY: Record<string, { label: string; hours: number }> = {
  critical: { label: "Критичный", hours: 0.25 },
  high: { label: "Высокий", hours: 2 },
  normal: { label: "Обычный", hours: 24 },
  low: { label: "Низкий", hours: 72 },
};
export const STAFF: Record<string, string> = { curator: "Куратор", teamlead: "Тимлид", admin: "Администратор" };
export const CALL_SLOTS = ["10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00", "18:00"];

export const REQUESTS: Record<string, { title: string; tl: number; desc: string }> = {
  accounts: { title: "Аккаунты", tl: 2, desc: "Аккаунты под конкретный тест. Заявка уходит тимлиду на одобрение, расход списывается с вашего бюджета." },
  cards: { title: "Карты", tl: 2, desc: "Виртуальные карты для оплаты рекламы: валюта, BIN, лимит и пополнение. Отдельная карта на аккаунт снижает риск связки банов." },
  creatives: { title: "Креативы", tl: 1, desc: "ТЗ дизайнеру по формуле «хук → проблема → решение → доказательство → CTA». Каждый креатив потом получает свою статистику." },
  appeal: { title: "Обращение", tl: 0, desc: "Предложение, жалоба или идея. Можно анонимно: имя увидит только администратор." },
  call: { title: "Созвон", tl: 0, desc: "Выберите, с кем и когда. Занятые слоты недоступны." },
};

export const DIARY_FIELDS_HINT = "Расход, доход, клики и лиды — ROI, CPL, CR и EPC посчитаются сами.";

export const MEETING_KIND: Record<string, string> = { meeting: "Мит команды", webinar: "Вебинар", case_review: "Разбор кейса", qa: "Ответы на вопросы" };
export const MEETING_VISIBILITY: Record<string, string> = { all: "Все ученики", buyers: "Только TL2+", staff: "Только команда" };
