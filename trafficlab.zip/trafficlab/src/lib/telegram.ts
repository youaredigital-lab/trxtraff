import { createAdminClient } from "./supabase/admin";

export async function sendTelegram(chatId: number | string, text: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token || !chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
    });
  } catch {
    // уведомление не критично
  }
}

const esc = (s: string) => s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]!));

/** Уведомить пользователя по id профиля (если привязан Telegram). */
export async function notifyUser(userId: string, text: string, path?: string) {
  const admin = createAdminClient();
  if (!admin || !process.env.TELEGRAM_BOT_TOKEN) return;
  const { data } = await admin.from("profiles").select("telegram_chat_id").eq("id", userId).single();
  if (!data?.telegram_chat_id) return;
  const link = path && process.env.NEXT_PUBLIC_SITE_URL ? `\n${process.env.NEXT_PUBLIC_SITE_URL}${path}` : "";
  await sendTelegram(data.telegram_chat_id, esc(text) + link);
}

/** Уведомить всех сотрудников с указанными ролями. */
export async function notifyStaff(text: string, path?: string, roles = ["curator", "teamlead", "admin"]) {
  const admin = createAdminClient();
  if (!admin || !process.env.TELEGRAM_BOT_TOKEN) return;
  const { data } = await admin.from("profiles").select("telegram_chat_id").in("role", roles).not("telegram_chat_id", "is", null);
  const link = path && process.env.NEXT_PUBLIC_SITE_URL ? `\n${process.env.NEXT_PUBLIC_SITE_URL}${path}` : "";
  await Promise.all((data ?? []).map((p) => sendTelegram(p.telegram_chat_id, esc(text) + link)));
}
