export const num = (v: unknown) => {
  const n = parseFloat(String(v ?? "").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
};
export const money = (v: number) =>
  (v < 0 ? "−$" : "$") + Math.abs(v).toLocaleString("ru-RU", { maximumFractionDigits: v % 1 ? 2 : 0 });
export const pct = (v: number) => (Number.isFinite(v) ? (v > 0 ? "+" : "") + v.toFixed(0) + "%" : "—");
export const tone = (v: number) => (v > 0 ? "text-pos" : v < 0 ? "text-neg" : "text-muted");

export type Metrics = { spend: number; rev: number; clicks: number; leads: number; profit: number; roi: number; cpl: number; cr: number; epc: number };
export function metrics(e: { spend?: any; revenue?: any; clicks?: any; leads?: any }): Metrics {
  const spend = num(e.spend), rev = num(e.revenue), clicks = num(e.clicks), leads = num(e.leads);
  const profit = rev - spend;
  return {
    spend, rev, clicks, leads, profit,
    roi: spend ? (profit / spend) * 100 : NaN,
    cpl: leads ? spend / leads : NaN,
    cr: clicks ? (leads / clicks) * 100 : NaN,
    epc: clicks ? rev / clicks : NaN,
  };
}
export function sumMetrics(list: any[]): Metrics {
  const t = list.reduce(
    (a, e) => ({ spend: a.spend + num(e.spend), revenue: a.revenue + num(e.revenue), clicks: a.clicks + num(e.clicks), leads: a.leads + num(e.leads) }),
    { spend: 0, revenue: 0, clicks: 0, leads: 0 }
  );
  return metrics(t);
}

export const dateShort = (s: string) => new Date(s).toLocaleDateString("ru-RU", { day: "numeric", month: "short" });
export function ago(t: string) {
  const m = Math.round((Date.now() - Date.parse(t)) / 6e4);
  if (m < 1) return "только что";
  if (m < 60) return `${m} мин назад`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} ч назад`;
  return `${Math.round(h / 24)} дн назад`;
}
export function dur(ms: number) {
  const h = Math.abs(ms) / 36e5;
  if (h < 1) return `${Math.round(h * 60)} мин`;
  if (h < 48) return `${h.toFixed(h < 10 ? 1 : 0)} ч`;
  return `${Math.round(h / 24)} дн`;
}
export const today = () => new Date().toISOString().slice(0, 10);
export const daysAgo = (n: number) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
