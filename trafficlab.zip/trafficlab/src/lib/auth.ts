import { redirect } from "next/navigation";
import { cache } from "react";
import { createClient } from "./supabase/server";

export type Stats = {
  lessons_done: number; quiz_points: number; hw_accepted: number; diary_count: number;
  plus_tests: number; proposals_approved: number; profit_30d: number; spend_30d: number;
  xp: number; trust_level: number;
};

export const getMe = cache(async () => {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const [{ data: profile }, { data: stats }] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).single(),
    supabase.rpc("user_stats", { p_uid: user.id }).single(),
  ]);
  const role = profile?.role ?? "student";
  return {
    supabase,
    user,
    profile: profile ?? { id: user.id, full_name: user.email, role },
    stats: (stats ?? { trust_level: 0, xp: 0 }) as Stats,
    isStaff: ["curator", "teamlead", "admin"].includes(role),
    isAdmin: ["teamlead", "admin"].includes(role),
  };
});

export async function requireStaff() {
  const me = await getMe();
  if (!me.isStaff) redirect("/");
  return me;
}
export async function requireAdmin() {
  const me = await getMe();
  if (!me.isAdmin) redirect("/");
  return me;
}
