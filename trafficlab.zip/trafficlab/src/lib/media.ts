import type { SupabaseClient } from "@supabase/supabase-js";

/** Превращает ссылку YouTube / Vimeo / Loom / Google Drive в адрес для встраивания. */
export function embedUrl(url: string): string | null {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (host === "youtu.be") return `https://www.youtube.com/embed/${u.pathname.slice(1)}`;
    if (host.endsWith("youtube.com")) {
      const id = u.searchParams.get("v") ?? u.pathname.split("/").filter(Boolean).pop();
      return id ? `https://www.youtube.com/embed/${id}` : null;
    }
    if (host === "vimeo.com") return `https://player.vimeo.com/video/${u.pathname.split("/").filter(Boolean)[0]}`;
    if (host.endsWith("loom.com")) return `https://www.loom.com/embed/${u.pathname.split("/").filter(Boolean).pop()}`;
    if (host === "drive.google.com") {
      const m = u.pathname.match(/\/file\/d\/([^/]+)/);
      return m ? `https://drive.google.com/file/d/${m[1]}/preview` : null;
    }
    return null;
  } catch {
    return null;
  }
}

/** Подписанная ссылка на файл из приватного бакета (по правам текущего пользователя). */
export async function signedMedia(supabase: SupabaseClient, path?: string | null) {
  if (!path) return null;
  const { data } = await supabase.storage.from("media").createSignedUrl(path, 60 * 60 * 3);
  return data?.signedUrl ?? null;
}
