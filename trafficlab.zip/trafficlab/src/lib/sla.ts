import { PRIORITY } from "./constants";

export const isClosed = (t: any) => t.status === "done" || t.status === "rejected";
/** Миллисекунды до нарушения SLA первого ответа; Infinity — ответ уже дан. */
export function slaLeft(t: any) {
  if (t.first_response_at) return Infinity;
  const p = PRIORITY[t.priority] ?? PRIORITY.normal;
  return p.hours * 36e5 - (Date.now() - Date.parse(t.created_at));
}
