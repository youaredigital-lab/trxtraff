-- TrafficLab — схема базы данных для Supabase (PostgreSQL 15+)
-- Применение: Supabase Dashboard → SQL Editor → вставить файл целиком, либо `supabase db push`.

create extension if not exists pgcrypto;

-- ============================================================
-- ENUMS
-- ============================================================
create type public.user_role       as enum ('student','buyer','curator','teamlead','admin');
create type public.hw_status       as enum ('submitted','accepted','returned');
create type public.test_status     as enum ('idea','approved','running','plus','minus','stopped');
create type public.proposal_status as enum ('pending','approved','rejected');
create type public.ticket_type     as enum ('ticket','accounts','cards','creatives','appeal','call');
create type public.ticket_priority as enum ('critical','high','normal','low');
create type public.ticket_status   as enum ('open','progress','waiting','done','rejected');

-- ============================================================
-- PROFILES
-- ============================================================
create table public.profiles (
  id                 uuid primary key references auth.users(id) on delete cascade,
  full_name          text not null default '',
  role               public.user_role not null default 'student',
  monthly_goal       numeric(12,2),
  telegram_chat_id   bigint,
  telegram_link_code text unique default encode(gen_random_bytes(6), 'hex'),
  created_at         timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)));
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.my_role() returns public.user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() in ('curator','teamlead','admin'), false)
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() in ('teamlead','admin'), false)
$$;

-- Роль меняет только админ (и сервисный ключ).
create or replace function public.guard_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.role is distinct from old.role then raise exception 'Только администратор меняет роли'; end if;
    if new.telegram_link_code is distinct from old.telegram_link_code
       or new.telegram_chat_id is distinct from old.telegram_chat_id then
      if new.telegram_chat_id is not null then raise exception 'Telegram привязывается через бота'; end if;
    end if;
  end if;
  return new;
end $$;
create trigger guard_profile before update on public.profiles
  for each row execute function public.guard_profile();

-- ============================================================
-- LEARNING
-- ============================================================
create table public.tracks (
  id       uuid primary key default gen_random_uuid(),
  title    text not null,
  position int  not null default 0
);

create table public.lessons (
  id         uuid primary key default gen_random_uuid(),
  track_id   uuid not null references public.tracks(id) on delete cascade,
  position   int  not null default 0,
  title      text not null,
  minutes    int  not null default 10,
  body       text not null default '',
  hw_prompt  text,
  hw_rubric  text[] not null default '{}',
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index on public.lessons (track_id, position);

create table public.quiz_questions (
  id        uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  position  int  not null default 0,
  question  text not null,
  options   text[] not null check (array_length(options, 1) >= 2),
  correct   int  not null check (correct >= 0)
);
create index on public.quiz_questions (lesson_id, position);

create table public.lesson_progress (
  user_id      uuid not null references public.profiles(id) on delete cascade,
  lesson_id    uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz,
  quiz_score   numeric(4,3),
  primary key (user_id, lesson_id)
);

create table public.homework (
  id          uuid primary key default gen_random_uuid(),
  lesson_id   uuid not null references public.lessons(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  answer      text not null check (length(answer) >= 10),
  link        text,
  status      public.hw_status not null default 'submitted',
  scores      int[],
  comment     text,
  ai_review   text,
  reviewer_id uuid references public.profiles(id),
  created_at  timestamptz not null default now(),
  reviewed_at timestamptz
);
create index on public.homework (status, created_at);
create index on public.homework (user_id);

-- ============================================================
-- OFFERS, PROPOSALS, TESTS
-- ============================================================
create table public.offer_groups (
  id         uuid primary key default gen_random_uuid(),
  vertical   text not null,
  name       text not null,
  sources    text[] not null default '{}',
  geos       text[] not null default '{}',
  tips       text,
  created_at timestamptz not null default now()
);

create table public.offers (
  id          uuid primary key default gen_random_uuid(),
  group_id    uuid not null references public.offer_groups(id) on delete cascade,
  name        text not null,
  network     text,
  payout      numeric(10,2) not null default 0,
  geo         text not null,
  approve     text,
  cap         text,
  landing_url text,
  is_private  boolean not null default false,
  proposal_id uuid,
  created_at  timestamptz not null default now()
);
create index on public.offers (group_id);

-- Ученики и байеры предлагают офферы для тестов; тимлид одобряет → оффер попадает в базу.
create table public.offer_proposals (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  name          text not null,
  network       text not null,
  url           text,
  vertical      text not null,
  group_id      uuid references public.offer_groups(id) on delete set null,
  payout        numeric(10,2) not null default 0,
  geo           text not null,
  sources       text[] not null default '{}',
  why           text not null check (length(why) >= 20),
  wants_to_test boolean not null default true,
  status        public.proposal_status not null default 'pending',
  admin_comment text,
  offer_id      uuid references public.offers(id) on delete set null,
  reviewed_by   uuid references public.profiles(id),
  created_at    timestamptz not null default now(),
  reviewed_at   timestamptz
);
create index on public.offer_proposals (status, created_at);

create table public.offer_tests (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  offer_id    uuid not null references public.offers(id) on delete cascade,
  source      text not null,
  geo         text not null,
  hypothesis  text not null check (length(hypothesis) >= 10),
  budget      numeric(10,2) not null check (budget > 0),
  stop_rule   text not null,
  status      public.test_status not null default 'idea',
  conclusion  text,
  approved_by uuid references public.profiles(id),
  created_at  timestamptz not null default now(),
  started_at  timestamptz,
  closed_at   timestamptz
);
create index on public.offer_tests (status);
create index on public.offer_tests (offer_id);

-- ============================================================
-- DIARY
-- ============================================================
create table public.diary_entries (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  entry_date      date not null default current_date,
  offer_id        uuid references public.offers(id) on delete set null,
  source          text not null,
  geo             text not null default '',
  spend           numeric(12,2) not null default 0 check (spend >= 0),
  revenue         numeric(12,2) not null default 0 check (revenue >= 0),
  clicks          int not null default 0 check (clicks >= 0),
  leads           int not null default 0 check (leads >= 0),
  mood            smallint check (mood between 1 and 5),
  worked          text,
  failed          text,
  plan            text,
  curator_comment text,
  comment_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now()
);
create index on public.diary_entries (user_id, entry_date desc);

-- ============================================================
-- TICKETS & REQUESTS
-- ============================================================
create table public.tickets (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  type              public.ticket_type not null default 'ticket',
  title             text not null,
  category          text,
  priority          public.ticket_priority not null default 'normal',
  status            public.ticket_status not null default 'open',
  anonymous         boolean not null default false,
  fields            jsonb not null default '{}',
  test_id           uuid references public.offer_tests(id) on delete set null,
  assignee_id       uuid references public.profiles(id),
  first_response_at timestamptz,
  csat              smallint check (csat between 1 and 5),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index on public.tickets (status, created_at);
create index on public.tickets (user_id);
-- Один слот созвона — одна активная заявка.
create unique index tickets_call_slot on public.tickets ((fields->>'staff'), (fields->>'day'), (fields->>'slot'))
  where type = 'call' and status <> 'rejected';

create table public.ticket_messages (
  id          uuid primary key default gen_random_uuid(),
  ticket_id   uuid not null references public.tickets(id) on delete cascade,
  author_id   uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  body        text not null check (length(body) > 0),
  is_internal boolean not null default false,
  is_staff    boolean not null default false,
  created_at  timestamptz not null default now()
);
create index on public.ticket_messages (ticket_id, created_at);

-- ============================================================
-- STATS & TRUST LEVEL
-- ============================================================
create or replace function public.user_stats(p_uid uuid)
returns table (
  lessons_done int, quiz_points numeric, hw_accepted int, diary_count int,
  plus_tests int, proposals_approved int, profit_30d numeric, spend_30d numeric,
  xp int, trust_level int
)
language plpgsql stable security definer set search_path = public as $$
declare
  v_done int; v_quiz numeric; v_hw int; v_diary int; v_plus int; v_prop int;
  v_profit numeric; v_spend numeric; v_tl int := 0; v_role public.user_role;
begin
  select count(*) filter (where completed_at is not null), coalesce(sum(quiz_score), 0)
    into v_done, v_quiz from lesson_progress where user_id = p_uid;
  select count(*) into v_hw from homework where user_id = p_uid and status = 'accepted';
  select count(*) into v_diary from diary_entries where user_id = p_uid;
  select count(*) into v_plus from offer_tests where user_id = p_uid and status = 'plus';
  select count(*) into v_prop from offer_proposals where user_id = p_uid and status = 'approved';
  select coalesce(sum(revenue - spend), 0), coalesce(sum(spend), 0) into v_profit, v_spend
    from diary_entries where user_id = p_uid and entry_date >= current_date - 30;
  select role into v_role from profiles where id = p_uid;

  if v_done >= 3 then v_tl := 1; end if;
  if v_tl >= 1 and v_done >= 6 and v_hw >= 1 then v_tl := 2; end if;
  if v_tl >= 2 and v_plus >= 1 then v_tl := 3; end if;
  if v_tl >= 3 and v_profit >= 1000 then v_tl := 4; end if;
  if v_role in ('curator','teamlead','admin') then v_tl := 4; end if;

  return query select v_done, v_quiz, v_hw, v_diary, v_plus, v_prop, v_profit, v_spend,
    (v_done * 50 + round(v_quiz * 50) + v_hw * 100 + v_diary * 10 + v_plus * 150 + v_prop * 75)::int,
    v_tl;
end $$;

create or replace function public.trust_level(p_uid uuid) returns int
language sql stable security definer set search_path = public as $$
  select trust_level from public.user_stats(p_uid)
$$;

create or replace function public.leaderboard(p_limit int default 20)
returns table (user_id uuid, full_name text, role public.user_role, xp int, trust_level int, profit_30d numeric)
language sql stable security definer set search_path = public as $$
  select p.id, p.full_name, p.role, s.xp, s.trust_level, s.profit_30d
  from profiles p cross join lateral user_stats(p.id) s
  where p.role in ('student','buyer')
  order by s.xp desc
  limit p_limit
$$;

-- Урок открыт, если предыдущий урок трека пройден.
create or replace function public.lesson_unlocked(p_uid uuid, p_lesson uuid) returns boolean
language sql stable security definer set search_path = public as $$
  with l as (select track_id, position from lessons where id = p_lesson),
  prev as (
    select x.id from lessons x, l
    where x.track_id = l.track_id and x.position < l.position
    order by x.position desc limit 1
  )
  select case
    when (select role from profiles where id = p_uid) in ('curator','teamlead','admin') then true
    when not exists (select 1 from prev) then true
    else exists (select 1 from lesson_progress lp, prev
                 where lp.user_id = p_uid and lp.lesson_id = prev.id and lp.completed_at is not null)
  end
$$;

-- Квиз проверяется на сервере: правильные ответы ученику не отдаются.
create or replace function public.submit_quiz(p_lesson uuid, p_answers int[])
returns json language plpgsql security definer set search_path = public as $$
declare v_total int; v_right int := 0; v_correct int[]; v_score numeric; i int;
begin
  if auth.uid() is null then raise exception 'Требуется вход'; end if;
  if not lesson_unlocked(auth.uid(), p_lesson) then raise exception 'Урок ещё закрыт'; end if;
  select array_agg(correct order by position) into v_correct from quiz_questions where lesson_id = p_lesson;
  v_total := coalesce(array_length(v_correct, 1), 0);
  if v_total = 0 then raise exception 'В уроке нет квиза'; end if;
  for i in 1..v_total loop
    if p_answers[i] is not distinct from v_correct[i] then v_right := v_right + 1; end if;
  end loop;
  v_score := round(v_right::numeric / v_total, 3);
  insert into lesson_progress (user_id, lesson_id, quiz_score, completed_at)
  values (auth.uid(), p_lesson, v_score, case when v_score >= 0.5 then now() end)
  on conflict (user_id, lesson_id) do update set
    quiz_score   = greatest(coalesce(lesson_progress.quiz_score, 0), excluded.quiz_score),
    completed_at = coalesce(lesson_progress.completed_at, excluded.completed_at);
  return json_build_object('right', v_right, 'total', v_total, 'score', v_score,
                           'passed', v_score >= 0.5, 'correct', v_correct);
end $$;

create or replace function public.complete_lesson(p_lesson uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Требуется вход'; end if;
  if exists (select 1 from quiz_questions where lesson_id = p_lesson) then
    raise exception 'Урок засчитывается после квиза';
  end if;
  if not lesson_unlocked(auth.uid(), p_lesson) then raise exception 'Урок ещё закрыт'; end if;
  insert into lesson_progress (user_id, lesson_id, completed_at) values (auth.uid(), p_lesson, now())
  on conflict (user_id, lesson_id) do update set completed_at = coalesce(lesson_progress.completed_at, now());
end $$;

-- Полный квиз (с ответами) — только для админки.
create or replace function public.admin_quiz(p_lesson uuid)
returns setof public.quiz_questions language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Нет доступа'; end if;
  return query select * from quiz_questions where lesson_id = p_lesson order by position;
end $$;

-- Занятые слоты созвонов (без раскрытия чужих заявок).
create or replace function public.taken_call_slots(p_staff text, p_day text)
returns setof text language sql stable security definer set search_path = public as $$
  select fields->>'slot' from tickets
  where type = 'call' and status <> 'rejected' and fields->>'staff' = p_staff and fields->>'day' = p_day
$$;

-- Похожие решённые тикеты для подсказки (без автора).
create or replace function public.similar_tickets(p_query text)
returns table (title text, answer text) language sql stable security definer set search_path = public as $$
  select t.title,
         (select m.body from ticket_messages m where m.ticket_id = t.id and m.is_staff and not m.is_internal
          order by m.created_at desc limit 1)
  from tickets t
  where t.type = 'ticket' and t.status = 'done' and length(p_query) >= 4
    and t.title ilike '%' || p_query || '%'
  order by t.updated_at desc limit 3
$$;

-- Одобрение предложенного оффера: создаёт оффер в базе.
create or replace function public.approve_proposal(p_id uuid, p_group uuid, p_comment text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_p offer_proposals; v_offer uuid;
begin
  if not is_admin() then raise exception 'Нет доступа'; end if;
  select * into v_p from offer_proposals where id = p_id for update;
  if v_p.id is null or v_p.status <> 'pending' then raise exception 'Предложение уже рассмотрено'; end if;
  insert into offers (group_id, name, network, payout, geo, landing_url, proposal_id)
  values (p_group, v_p.name, v_p.network, v_p.payout, v_p.geo, v_p.url, v_p.id)
  returning id into v_offer;
  update offer_proposals set status = 'approved', offer_id = v_offer, group_id = p_group,
    admin_comment = p_comment, reviewed_by = auth.uid(), reviewed_at = now()
  where id = p_id;
  return v_offer;
end $$;

-- ============================================================
-- GUARDS (бизнес-правила, которые нельзя обойти из клиента)
-- ============================================================
create or replace function public.guard_homework() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.user_id := auth.uid(); new.status := 'submitted'; new.scores := null;
    new.comment := null; new.reviewer_id := null; new.reviewed_at := null;
  elsif not is_staff() then
    raise exception 'ДЗ проверяет куратор';
  else
    new.reviewer_id := auth.uid(); new.reviewed_at := now();
  end if;
  return new;
end $$;
create trigger guard_homework before insert or update on public.homework
  for each row execute function public.guard_homework();

create or replace function public.guard_test() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.user_id := auth.uid();
    if is_staff() then
      new.status := coalesce(nullif(new.status, 'idea'), 'approved'); new.approved_by := auth.uid();
    else
      if trust_level(auth.uid()) < 2 then raise exception 'Тесты офферов открываются на Trust Level 2'; end if;
      new.status := 'idea';
    end if;
    return new;
  end if;
  if new.status is distinct from old.status then
    if new.status in ('plus','minus') and coalesce(length(new.conclusion), 0) < 10 then
      raise exception 'Перед закрытием теста напишите вывод';
    end if;
    if not is_staff() then
      if not ((old.status = 'approved' and new.status = 'running')
           or (old.status = 'running' and new.status in ('plus','minus','stopped'))) then
        raise exception 'Недопустимая смена статуса';
      end if;
    end if;
    if new.status = 'approved' then new.approved_by := auth.uid(); end if;
    if new.status = 'running' then new.started_at := now(); end if;
    if new.status in ('plus','minus','stopped') then new.closed_at := now(); end if;
  end if;
  if not is_staff() and (new.offer_id <> old.offer_id or new.budget <> old.budget or new.user_id <> old.user_id) then
    raise exception 'Параметры теста меняет тимлид';
  end if;
  return new;
end $$;
create trigger guard_test before insert or update on public.offer_tests
  for each row execute function public.guard_test();

create or replace function public.guard_proposal() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.user_id := auth.uid(); new.status := 'pending'; new.offer_id := null;
    new.reviewed_by := null; new.reviewed_at := null; new.admin_comment := null;
  elsif not is_admin() then
    if old.status <> 'pending' then raise exception 'Рассмотренное предложение не редактируется'; end if;
    if new.status <> 'pending' then raise exception 'Статус меняет тимлид'; end if;
  elsif new.status is distinct from old.status then
    new.reviewed_by := auth.uid(); new.reviewed_at := now();
  end if;
  return new;
end $$;
create trigger guard_proposal before insert or update on public.offer_proposals
  for each row execute function public.guard_proposal();

create or replace function public.guard_diary() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then new.user_id := auth.uid(); new.curator_comment := null; return new; end if;
  if old.user_id <> auth.uid() then
    -- куратор меняет только комментарий
    if (to_jsonb(new) - 'curator_comment' - 'comment_by') <> (to_jsonb(old) - 'curator_comment' - 'comment_by') then
      raise exception 'Куратор может только комментировать запись';
    end if;
    new.comment_by := auth.uid();
  else
    new.curator_comment := old.curator_comment; new.comment_by := old.comment_by;
  end if;
  return new;
end $$;
create trigger guard_diary before insert or update on public.diary_entries
  for each row execute function public.guard_diary();

create or replace function public.guard_ticket() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_tl int;
begin
  if tg_op = 'INSERT' then
    new.user_id := auth.uid(); new.status := 'open'; new.first_response_at := null; new.csat := null;
    v_tl := trust_level(auth.uid());
    if new.type in ('accounts','cards') and v_tl < 2 then
      raise exception 'Заявки на аккаунты и карты открываются на Trust Level 2';
    end if;
    if new.type = 'creatives' and v_tl < 1 then
      raise exception 'Заказ креативов открывается на Trust Level 1';
    end if;
    if new.type <> 'appeal' then new.anonymous := false; end if;
    return new;
  end if;
  if not is_staff() then
    if (to_jsonb(new) - 'csat' - 'updated_at' - 'status') <> (to_jsonb(old) - 'csat' - 'updated_at' - 'status')
       or (new.status is distinct from old.status and not (old.status = 'waiting' and new.status = 'progress'))
       or (new.csat is distinct from old.csat and old.status not in ('done','rejected')) then
      raise exception 'Автор может только оценить решение';
    end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger guard_ticket before insert or update on public.tickets
  for each row execute function public.guard_ticket();

create or replace function public.on_ticket_message() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.author_id := auth.uid();
  new.is_staff := is_staff();
  if new.is_internal and not new.is_staff then new.is_internal := false; end if;
  update tickets set
    updated_at = now(),
    first_response_at = case when new.is_staff and not new.is_internal and first_response_at is null
                             then now() else first_response_at end,
    status = case
      when new.is_staff and not new.is_internal and status = 'open' then 'progress'::ticket_status
      when not new.is_staff and status = 'waiting' then 'progress'::ticket_status
      else status end
  where id = new.ticket_id;
  return new;
end $$;
create trigger on_ticket_message before insert on public.ticket_messages
  for each row execute function public.on_ticket_message();

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.profiles         enable row level security;
alter table public.tracks           enable row level security;
alter table public.lessons          enable row level security;
alter table public.quiz_questions   enable row level security;
alter table public.lesson_progress  enable row level security;
alter table public.homework         enable row level security;
alter table public.offer_groups     enable row level security;
alter table public.offers           enable row level security;
alter table public.offer_proposals  enable row level security;
alter table public.offer_tests      enable row level security;
alter table public.diary_entries    enable row level security;
alter table public.tickets          enable row level security;
alter table public.ticket_messages  enable row level security;

-- profiles
create policy "profiles: read all"    on public.profiles for select to authenticated using (true);
create policy "profiles: update own"  on public.profiles for update to authenticated using (id = auth.uid() or public.is_admin());

-- content: читают все, пишет админ
create policy "tracks: read"   on public.tracks for select to authenticated using (true);
create policy "tracks: admin"  on public.tracks for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "lessons: read"  on public.lessons for select to authenticated using (true);
create policy "lessons: admin" on public.lessons for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "quiz: read"     on public.quiz_questions for select to authenticated using (true);
create policy "quiz: admin"    on public.quiz_questions for all to authenticated using (public.is_admin()) with check (public.is_admin());
revoke select on public.quiz_questions from anon, authenticated;
grant select (id, lesson_id, position, question, options) on public.quiz_questions to authenticated;

create policy "groups: read"   on public.offer_groups for select to authenticated using (true);
create policy "groups: admin"  on public.offer_groups for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "offers: read"   on public.offers for select to authenticated
  using (not is_private or public.trust_level(auth.uid()) >= 4);
create policy "offers: admin"  on public.offers for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- progress: только через RPC
create policy "progress: read own" on public.lesson_progress for select to authenticated
  using (user_id = auth.uid() or public.is_staff());

-- homework
create policy "hw: read"   on public.homework for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "hw: submit" on public.homework for insert to authenticated with check (true);
create policy "hw: review" on public.homework for update to authenticated using (public.is_staff());

-- proposals
create policy "proposals: read"   on public.offer_proposals for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "proposals: create" on public.offer_proposals for insert to authenticated with check (true);
create policy "proposals: update" on public.offer_proposals for update to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "proposals: delete" on public.offer_proposals for delete to authenticated using (user_id = auth.uid() and status = 'pending');

-- tests: видит вся команда (обучение на чужих тестах)
create policy "tests: read"   on public.offer_tests for select to authenticated using (true);
create policy "tests: create" on public.offer_tests for insert to authenticated with check (true);
create policy "tests: update" on public.offer_tests for update to authenticated using (user_id = auth.uid() or public.is_staff());

-- diary
create policy "diary: read"   on public.diary_entries for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "diary: create" on public.diary_entries for insert to authenticated with check (true);
create policy "diary: update" on public.diary_entries for update to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "diary: delete" on public.diary_entries for delete to authenticated using (user_id = auth.uid());

-- tickets
create policy "tickets: read"   on public.tickets for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "tickets: create" on public.tickets for insert to authenticated with check (true);
create policy "tickets: update" on public.tickets for update to authenticated using (user_id = auth.uid() or public.is_staff());

create policy "messages: read" on public.ticket_messages for select to authenticated using (
  exists (select 1 from public.tickets t where t.id = ticket_id and (t.user_id = auth.uid() or public.is_staff()))
  and (not is_internal or public.is_staff()));
create policy "messages: write" on public.ticket_messages for insert to authenticated with check (
  exists (select 1 from public.tickets t where t.id = ticket_id and (t.user_id = auth.uid() or public.is_staff())));

-- RPC доступ
grant execute on function public.user_stats(uuid), public.trust_level(uuid), public.leaderboard(int),
  public.lesson_unlocked(uuid, uuid), public.submit_quiz(uuid, int[]), public.complete_lesson(uuid),
  public.admin_quiz(uuid), public.taken_call_slots(text, text), public.similar_tickets(text),
  public.approve_proposal(uuid, uuid, text), public.is_staff(), public.is_admin(), public.my_role()
  to authenticated;
