-- TrafficLab — видеоуроки и записи митов
-- Видео хранится либо в Supabase Storage (бакет media), либо по внешней ссылке (YouTube, Vimeo, Loom, Google Drive).

alter table public.lessons
  add column video_path text,
  add column video_url  text;

create type public.meeting_kind as enum ('meeting','webinar','case_review','qa');
create type public.meeting_visibility as enum ('all','buyers','staff');

create table public.meetings (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  description  text not null default '',
  kind         public.meeting_kind not null default 'meeting',
  visibility   public.meeting_visibility not null default 'all',
  recorded_at  date not null default current_date,
  duration_min int,
  video_path   text,
  video_url    text,
  track_id     uuid references public.tracks(id) on delete set null,
  tags         text[] not null default '{}',
  created_by   uuid references public.profiles(id) default auth.uid(),
  created_at   timestamptz not null default now(),
  check (video_path is not null or video_url is not null)
);
create index on public.meetings (recorded_at desc);

-- Кто что посмотрел (для прогресса и статистики админа)
create table public.meeting_views (
  user_id    uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  meeting_id uuid not null references public.meetings(id) on delete cascade,
  viewed_at  timestamptz not null default now(),
  primary key (user_id, meeting_id)
);

alter table public.meetings enable row level security;
alter table public.meeting_views enable row level security;

create policy "meetings: read" on public.meetings for select to authenticated using (
  visibility = 'all'
  or (visibility = 'buyers' and (public.trust_level(auth.uid()) >= 2))
  or public.is_staff());
create policy "meetings: admin" on public.meetings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

create policy "views: own" on public.meeting_views for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy "views: mark" on public.meeting_views for insert to authenticated with check (user_id = auth.uid());

-- ============================================================
-- STORAGE: приватный бакет media
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', false, null, array['video/mp4','video/webm','video/quicktime','video/x-matroska','audio/mpeg','audio/mp4','application/pdf'])
on conflict (id) do nothing;

-- Видео урока видят все; запись мита — только те, кому видна сама запись (RLS meetings применяется в подзапросе).
create policy "media: read" on storage.objects for select to authenticated using (
  bucket_id = 'media' and (
    name like 'lessons/%'
    or exists (select 1 from public.meetings m where m.video_path = storage.objects.name)
    or public.is_staff()));
create policy "media: admin upload" on storage.objects for insert to authenticated with check (bucket_id = 'media' and public.is_admin());
create policy "media: admin update" on storage.objects for update to authenticated using (bucket_id = 'media' and public.is_admin());
create policy "media: admin delete" on storage.objects for delete to authenticated using (bucket_id = 'media' and public.is_admin());
