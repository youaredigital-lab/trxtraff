import type { Config } from "tailwindcss";

const c = (v: string) => `rgb(var(--${v}) / <alpha-value>)`;

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: c("bg"), panel: c("panel"), sunk: c("sunk"), ink: c("ink"), muted: c("muted"), line: c("line"),
        accent: c("accent"), "accent-ink": c("accent-ink"), "accent-soft": c("accent-soft"),
        pos: c("pos"), "pos-soft": c("pos-soft"), neg: c("neg"), "neg-soft": c("neg-soft"),
        warn: c("warn"), "warn-soft": c("warn-soft"),
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      borderRadius: { card: "10px" },
    },
  },
  plugins: [],
} satisfies Config;
